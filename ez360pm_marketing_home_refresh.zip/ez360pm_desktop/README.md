# EZ360PM Desktop (Skeleton)

Offline-first Windows desktop skeleton for EZ360PM.

## Install & run

From `ez360pm_desktop/`:

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python -m app.main
