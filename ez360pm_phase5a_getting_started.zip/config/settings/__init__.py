"""Settings package.

Set DJANGO_SETTINGS_MODULE to one of:
- config.settings.dev
- config.settings.prod

A compatibility shim exists at config/settings.py.
"""
