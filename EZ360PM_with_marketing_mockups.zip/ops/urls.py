from django.urls import path

from . import views

app_name = "ops"

urlpatterns = [
    path("healthz/", views.healthz, name="healthz"),
    path("", views.ops_dashboard, name="dashboard"),

    # Settings (staff-managed, no Django admin required)
    path("settings/", views.ops_settings_home, name="settings_home"),
    path("settings/billing/", views.ops_settings_billing, name="settings_billing"),
    path("settings/site/", views.ops_settings_site, name="settings_site"),

    path("system/", views.ops_system_status, name="system_status"),
    path("smoke/", views.ops_smoke_tests, name="smoke_tests"),
    path("slo/", views.ops_slo_dashboard, name="slo_dashboard"),
    path("pii-export/", views.ops_pii_export, name="pii_export"),
    path("alerts/", views.ops_alerts, name="alerts"),
    path("alerts/export.csv", views.ops_alerts_export_csv, name="alerts_export_csv"),
    path("alerts/send-test/", views.ops_alert_send_test, name="alert_send_test"),
    path("alerts/<int:alert_id>/", views.ops_alert_detail, name="alert_detail"),
    path("alerts/snooze/", views.ops_alert_snooze, name="alert_snooze"),
    path("alerts/snooze/clear/", views.ops_alert_snooze_clear, name="alert_snooze_clear"),
    path("alerts/snoozes/", views.ops_alert_snoozes, name="alert_snoozes"),
    path("alerts/snoozes/<int:pk>/", views.ops_alert_snooze_detail, name="alert_snooze_detail"),
    path("alerts/snoozes/<int:pk>/delete/", views.ops_alert_snooze_delete, name="alert_snooze_delete"),
    path("alerts/<int:alert_id>/details.json", views.ops_alert_details_json, name="alert_details_json"),
    path("alert-routing/", views.ops_alert_routing, name="alert_routing"),
    path("alerts/<int:alert_id>/resolve/", views.ops_alert_resolve, name="alert_resolve"),
    path("security/", views.ops_security, name="security"),
    path("launch-checks/", views.ops_launch_checks, name="launch_checks"),
    path("email-test/", views.ops_email_test, name="email_test"),
    path("checks/", views.ops_checks, name="checks"),
    path("checks/runs/<int:run_id>/download/", views.ops_check_run_download, name="check_run_download"),
    path("checks/runs/export/", views.ops_check_runs_export, name="check_runs_export"),
    path("probes/", views.ops_probes, name="probes"),
    path("probes/test-error/", views.ops_probe_test_error, name="probe_test_error"),
    path("probes/test-alert/", views.ops_probe_test_alert, name="probe_test_alert"),
    path("launch-gate/", views.ops_launch_gate, name="launch_gate"),
    path("launch-gate/seed/", views.ops_launch_gate_seed, name="launch_gate_seed"),
    path("runbook/", views.ops_go_live_runbook, name="go_live_runbook"),
    path("runbook/export.csv", views.ops_go_live_runbook_export_csv, name="go_live_runbook_export_csv"),
    path("runbook/export.pdf", views.ops_go_live_runbook_export_pdf, name="go_live_runbook_export_pdf"),
    path("reconciliation/", views.ops_reconciliation, name="reconciliation"),
    path("drift/", views.ops_drift_tools, name="drift_tools"),
    path("drift/recalc/", views.ops_drift_recalc, name="drift_recalc"),
    path("drift/link-payment/", views.ops_drift_link_payment, name="drift_link_payment"),
    path("drift/post-missing/", views.ops_drift_post_missing, name="drift_post_missing"),
    path("launch-gate/<int:item_id>/toggle/", views.ops_launch_gate_toggle, name="launch_gate_toggle"),
    path("retention/", views.ops_retention, name="retention"),
    path("retention/prune/", views.ops_retention_prune, name="retention_prune"),
    path("backups/", views.ops_backups, name="backups"),
    path("backups/run-now/", views.ops_backup_run_now, name="backup_run_now"),
    path("backups/prune/", views.ops_backup_prune, name="backup_prune"),
    path("backups/record-run/", views.ops_backup_record_run, name="backup_record_run"),
    path("backups/record-restore-test/", views.ops_backup_record_restore_test, name="backup_record_restore_test"),
    path("releases/", views.ops_releases, name="releases"),

    # QA punchlist (Phase 8S2)
    path("qa/", views.ops_qa_issues, name="qa_issues"),
    path("qa/new/", views.ops_qa_issue_new, name="qa_issue_new"),
    path("qa/<int:pk>/", views.ops_qa_issue_detail, name="qa_issue_detail"),
    path("qa/<int:pk>/edit/", views.ops_qa_issue_edit, name="qa_issue_edit"),
    path("qa/<int:pk>/close/", views.ops_qa_issue_close, name="qa_issue_close"),
    # Company primary keys are UUIDs.
    path("companies/<uuid:company_id>/", views.ops_company_detail, name="company_detail"),
    path("companies/<uuid:company_id>/timeline/", views.ops_company_timeline, name="company_timeline"),
    path("companies/<uuid:company_id>/resync-subscription/", views.ops_resync_subscription, name="resync_subscription"),
]
