from __future__ import annotations

from django.db import models
from django.utils import timezone

from companies.models import Company


class OpsAlertLevel(models.TextChoices):
    INFO = "info", "Info"
    WARN = "warn", "Warning"
    ERROR = "error", "Error"


class OpsAlertSource(models.TextChoices):
    STRIPE_WEBHOOK = "stripe_webhook", "Stripe webhook"
    EMAIL = "email", "Email"
    SLOW_REQUEST = "slow_request", "Slow request"
    AUTH = "auth", "Auth"
    THROTTLE = "throttle", "Throttle"
    LAUNCH_GATE = "launch_gate", "Launch gate"


class OpsAlertEvent(models.Model):
    """Lightweight staff-visible ops alerts.

    Goals:
    - Capture *actionable* failures and key degradations.
    - Safe for prod; never blocks request paths.
    - Supports acknowledgement (resolved) workflow.
    """

    created_at = models.DateTimeField(default=timezone.now, db_index=True)
    level = models.CharField(max_length=16, choices=OpsAlertLevel.choices, default=OpsAlertLevel.ERROR, db_index=True)
    source = models.CharField(max_length=32, choices=OpsAlertSource.choices, default=OpsAlertSource.EMAIL, db_index=True)

    # Company is optional because some alerts are platform-wide.
    company = models.ForeignKey(Company, null=True, blank=True, on_delete=models.SET_NULL, related_name="ops_alerts")

    title = models.CharField(max_length=200)
    message = models.TextField(blank=True, default="")
    details = models.JSONField(default=dict, blank=True)

    is_resolved = models.BooleanField(default=False, db_index=True)
    resolved_at = models.DateTimeField(null=True, blank=True)
    resolved_by_email = models.EmailField(blank=True, default="")

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["source", "level", "created_at"]),
            models.Index(fields=["company", "is_resolved", "created_at"]),
        ]

    def __str__(self) -> str:
        return f"[{self.level}] {self.source}: {self.title}"

    def resolve(self, *, by_email: str | None = None, save: bool = True) -> None:
        self.is_resolved = True
        self.resolved_at = timezone.now()
        self.resolved_by_email = (by_email or "").strip()[:254]
        if save:
            self.save(update_fields=["is_resolved", "resolved_at", "resolved_by_email"])


class LaunchGateItem(models.Model):
    """Staff-managed launch readiness gate checklist.

    This is a *process* artifact that complements the automated checks in
    `core.launch_checks.run_launch_checks()`.
    """

    key = models.SlugField(max_length=64, unique=True)
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True, default="")

    is_complete = models.BooleanField(default=False, db_index=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    completed_by = models.ForeignKey(
        "accounts.User",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="completed_launch_gate_items",
    )

    notes = models.TextField(blank=True, default="")

    created_at = models.DateTimeField(default=timezone.now, db_index=True)
    updated_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["key"]

    def mark_complete(self, *, user=None):
        self.is_complete = True
        self.completed_at = timezone.now()
        if user is not None:
            self.completed_by = user
        self.updated_at = timezone.now()

    def mark_incomplete(self):
        self.is_complete = False
        self.completed_at = None
        self.completed_by = None
        self.updated_at = timezone.now()

    def __str__(self) -> str:
        return f"{self.key}: {self.title}"
