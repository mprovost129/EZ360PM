EZ360PM Approved Brand Pack (from approved design)

Included:
- Primary logo (white background): PNG + SVG wrapper
- Primary logo (dark background): PNG + SVG wrapper
- App icon (white background): PNG + SVG wrapper + multiple sizes
- App icon (transparent): PNG + SVG wrapper + multiple sizes

Note on SVGs:
These SVG files are "SVG wrappers" that reference the matching PNG assets for pixel-perfect fidelity to the approved design.
If you need fully editable vector paths (true SVG), we can recreate the swoosh and typography as vector geometry in a follow-up step.
