# Media Storage (Uploads)

Default behavior:
- Uploaded files are stored on the local filesystem at `MEDIA_ROOT`, served at `MEDIA_URL`.

## Option: S3 / S3-compatible storage

This project supports S3-based media storage via **django-storages**.

1) Install dependency:
- `pip install "django-storages[boto3]"`

2) Set env vars:
- `USE_S3=1`
- `AWS_ACCESS_KEY_ID=...`
- `AWS_SECRET_ACCESS_KEY=...`
- `AWS_STORAGE_BUCKET_NAME=...`
- `AWS_S3_REGION_NAME=...`
- Optional:
  - `AWS_S3_ENDPOINT_URL=...` (MinIO / DigitalOcean Spaces / etc.)
  - `AWS_S3_CUSTOM_DOMAIN=media.yourdomain.com` (recommended)

3) Verify:
- Upload a receipt or document attachment in the app.
- Confirm the stored file URL resolves and loads.

Notes:
- Static files are still served via `collectstatic` (filesystem) by default.
- Media URLs will use `AWS_S3_CUSTOM_DOMAIN` when provided.

