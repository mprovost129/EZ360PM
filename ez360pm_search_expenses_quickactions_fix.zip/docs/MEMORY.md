## 2026-02-19 — Dashboard Quick Actions Dropdown

- Collapsed the dashboard “Quick actions” buttons into a single **+ New** dropdown for a cleaner right-rail layout.
- Track time remains available for all users; creation actions remain manager-gated.
- Dashboard layout adjustments:
  - Sidebar company dropdown: removed duplicate “Active company” label under the dropdown; added a **Switch company** item inside the dropdown.
  - Dashboard right rail: enforced ordering **Quick notes** above **Getting started** and removed legacy right-rail widgets (Outstanding invoices / Active company / Your role / Subscription) even if older saved layouts include them.

## 2026-02-18 — Phase 9 Pack: P9-DASH-RIGHT-ACTIONS (DONE)

## 2026-02-19 — UI Layer Consistency Sweep

Updated `static/css/ez360pm.css` to introduce a structured surface system:
- Navbar uses a subtle brand-tinted background with divider + soft shadow
- Sidebar gets a light surface and divider (active item styling intentionally unchanged)
- Cards use light gray surfaces with borders for hierarchy
- Inputs remain white with branded focus ring
- Tables/dropdowns/modals get consistent elevation and spacing cues

## 2026-02-19 — Company settings edit permission fix

- Fixed `companies:settings` so owners/admins can edit (previously template expected `form` + `can_edit` but the view did not provide them, causing everyone to appear read-only).
- Added `CompanySettingsForm` (dashboard-editable Company fields) and wired POST/GET handling.
- Non-owner/admin users see settings read-only with form fields disabled and a clear warning.


- 2026-02-18: Dashboard refresh pack: added KPI Period filter (month/30/90/YTD), clarified KPI time-basis, and updated dashboard to focus on three monitoring lists (Outstanding invoices by due date, Recent open projects, Recent expenses). Removed time-entry panel from dashboard.

- Dashboard UX polish: moved **Quick actions** into the right rail by default so the main column reads as a report while actions remain always available.
- Updated layout resolver to place required widgets into their configured default column (prevents forced-left placement).

## 2026-02-18 — Phase 9 Pack: P9-DOC-TAX-SERVER (DONE)

- Hardened server-side document totals by recomputing taxable line tax from `sales_tax_percent` in `recalc_document_totals`.
- Added documents regression test ensuring tax/total rollups remain correct even without JS.


## 2026-02-18 — Phase 9 — Legal pages smoke tests (P9-LEGAL-SMOKE)

- Added automated smoke tests to ensure all public legal pages render (prevents `TemplateDoesNotExist` regressions in production).
- Target pages: Terms, Privacy, Cookies, Acceptable Use, Security, Refund Policy.

## 2026-02-18 — Phase 9 — Legal policies content (P9-LEGAL-POLICIES)

- Replaced placeholder legal text with full production-ready policies aligned to EZ360PM features:
  - Terms of Service (includes seats/trials/Stripe billing, refund/proration rules, export responsibility)
  - Privacy Policy (includes Stripe/Plaid/Dropbox/Sentry/AWS/Render, retention, transfers, rights)
  - Cookies Policy (necessary/preferences/optional analytics, DNT note)
  - Security page (safeguards + account security responsibilities)
  - Acceptable Use Policy
  - Refund Policy (summary page)
- Standardized legal “Last updated” date via `legal_last_updated` context on helpcenter legal views.

## 2026-02-18 — Phase 9 — P9-BANK-DUPE-LINK shipped

- Bank Review Queue duplicate-prevention improved:
  - Added “Link suggested” action to bind a transaction to a suggested existing Expense.
  - Prevented creating a new expense when a strong duplicate match exists (>=90).

## 2026-02-18 — Phase 9 (P9-DOC-PDF) — Customer-facing Print/PDF Export
- Added customer-facing document output for Invoice / Estimate / Proposal:
  - Print preview (HTML): `/documents/<type>/<id>/print/`
  - PDF download (WeasyPrint optional): `/documents/<type>/<id>/pdf/`
- Output layout matches the paper-style composer: header branding, company block, client block, dates/meta, line items, totals, notes, and invoice terms.
- PDF route is best-effort and falls back to Print view with a friendly error when WeasyPrint/system deps are missing.
- Added composer toolbar actions: **Print** + **PDF**.


## 2026-02-17 — Phase 8I (DONE) — Mobile polish
- Topbar actions popover now fits on phones (uses left+right inset rather than fixed min-width).
- Timer dropdown menu is responsive on small screens (prevents clipped menus).
- Tables inside `.table-responsive` get a minimum width for reliable horizontal scrolling.
- Sticky form footer includes iOS safe-area bottom padding.


## 2026-02-17 — Phase 9 Fix Pack (P9-UI-CONSISTENCY + Repo hygiene)
- UI consistency: standardized **all cards** to the same baseline styling (rounded, borderless, consistent shadow) even if a template forgot `shadow-sm`.
- UI consistency: standardized **all dropdown menus** (radius + shadow + spacing) so action menus feel consistent across pages.
- Repo hygiene: removed accidental artifacts from the shipped bundle (`.venv/`, `__pycache__/`, `*.pyc`, and the leftover `_insert_phase9_views.txt`).
- Added a project `.gitignore` so virtualenvs, caches, local DB/media, and env files don’t get committed again.


## 2026-02-17 — Phase 8H (Brand pass)
- UI tokens: aligned Bootstrap primary/success/link/border/body CSS variables to EZ360PM brand tokens.
- Buttons: brand-aligned `.btn-ez` and `.btn-outline-primary` styling (Bootstrap-compatible).
- Forms: standardized form control radius + focus ring (light/dark), improving consistency across all CRUD flows.

## 2026-02-16 — Phase 8G (Help Center UX)
- Help: upgraded the navbar Help icon into a dropdown with quick links (Help Center, Getting started, FAQ, Terms, Privacy).
- Help Center: added sidebar search input that filters guide/legal links (client-side; no backend changes).
- Public site: navbar Help now routes to the Help Center.

## 2026-02-16 — Phase 8F (Micro-interactions)
- UI: auto-dismiss non-critical flash alerts (success/info) after a short delay.
- UX: added POST submit-guard that disables submit buttons to prevent double-submits and shows a small spinner on the submit button.
- UX: added a lightweight confirm helper for destructive actions via `data-ez-confirm` (opt-in per link/form).

## 2026-02-16 — Phase 8B (Dashboard redesign)
- Dashboard: added KPI row (Revenue, Expenses, A/R, Unbilled hours) with month label.
- Dashboard: added Recent Invoices + Recent Time panels and a Due-soon Projects panel.
- Dashboard: wired the dashboard view to compute KPI/payables metrics and avoid template context gaps.

## 2026-02-16 — Phase 7H48
- Ops: fixed missing `staff_only` decorator in `ops/views.py` (prevents import-time crash on alert views).
- UX: added navigation links to Collections follow-ups and Snoozes from relevant pages.

## 2026-02-16 — Phase 7H47
- Statements: added company-wide **Collections Follow-ups Due** queue (open notes with follow-up date due) with search + “Mark done” flow.
- Ops: added **Alert Snoozes** list/detail for audit visibility.
- Ops: added expired snooze pruning (`ops/management/commands/ez360_prune_ops_snoozes.py`) and a retention knob in Ops SiteConfig (`ops_snooze_prune_after_days`).

## 2026-02-16 — Phase 7H46
- Help Center: added an admin checklist for screenshot key completeness (`/admin/helpcenter/helpcenterscreenshot/required-keys/`) backed by `helpcenter/required_screenshots.py`.
- Ops Dashboard: snoozed groupings now show the “until” timestamp inline and include a one-click Clear Snooze action.
- Statements: Client Statement now includes per-client Collections Notes with optional follow-up date and “Done” completion.

## 2026-02-16 — Phase 7H45
- Help Center screenshots are now DB-uploadable via `HelpCenterScreenshot` (admin) and help templates use the `hc_screenshot` tag to fallback to static placeholders.
- Client Statement page now shows last viewed / last sent summary (from `ClientStatementActivity`).
- Clients list includes optional statement activity columns (viewed/sent).
- Ops Dashboard shows active snooze state and offers 30m/2h/1d/7d snooze quick-picks for alert groupings.

## 2026-02-16 — Phase 7H42 (Statement tone preview + Reminder bulk actions + Ops export/quick snooze)

**Shipped:**
- Statements:
  - Statement email now supports **Tone** selection (Standard/Friendly/Past due).
  - Statement email preview modal previews the selected tone.
  - Reminder scheduler now supports **Preview reminder email** before scheduling.
  - Added company-wide **Statement Reminders** queue with bulk cancel/reschedule.
- Ops:
  - Alerts list shows `dedup_count` (Dup column) when alerts were deduplicated.
  - Added quick snooze actions from the list view.
  - Added one-click CSV export for unresolved alerts (filters respected, capped).

## 2026-02-16 — Phase 7H29 (Daily ops alert routing + Financial statement help)

**Shipped:**
- `ez360_run_ops_checks_daily` now raises an Ops Alert + optional admin email when any scheduled check fails.
- Help Center: added Profit & Loss, Balance Sheet, and Trial Balance pages; linked from Help Home + sidebar.
- Accounting report pages now include contextual Help links to these Help Center articles.

## 2026-02-16 — Phase 7H32 (Statements PDF/email hardening + SITE_BASE_URL readiness + Ops copy JSON)

**Shipped:**
- Statements:
  - Added optional “Attach PDF” checkbox on statement emails (WeasyPrint-only).
  - Improved statement PDF styling for print (Letter sizing, margins, page numbers, cleaner header/table layout).
  - Fixed statement PDF/email redirect flows and querystring handling.
- Readiness:
  - Added `SITE_BASE_URL` check (warns when blank with DEBUG=False) so email deep links remain reliable.
- Ops:
  - Added alert detail links in the Ops Alerts list table.
  - Added “Copy JSON” button on alert detail page.

**Why:**
- Statement delivery must work for “print + email” workflows with predictable links.
- Staff needs quick access to alert details (and a copy-to-clipboard affordance) for vendor support tickets.

## 2026-02-16 — Phase 7H20 (Template/Static sanity + Readiness staticfiles)

**Shipped:**
- Fixed `ez360_template_sanity_check` regex and expanded checks:
  - Flags templates using `|money` / `|money_cents` without `{% load money %}` (FAIL).
  - Warns on `{% static %}` usage without `{% load static %}`.
  - Warns on parentheses inside `{% if %}` tags (common Django template break).
- Expanded `ez360_readiness_check` to validate staticfiles configuration:
  - In prod (`DEBUG=False`), fails if `STATIC_ROOT` is missing or does not exist (collectstatic not run).
  - Validates `STATIC_ROOT` is writable for local filesystem cases.

**Why:**
- Prevent repeat “template gotcha” regressions and catch missing tag loads early.
- Corporate deployments must treat staticfiles readiness as a launch gate.

## 2026-02-16 — Phase 7H15 (Ops subscription seat limit fix)
**Shipped:**
- Fixed Ops Console crash: `CompanySubscription` has no `seats_limit` attribute.
- Ops dashboards now compute seat limits via `billing.services.seats_limit_for(subscription)`.

**Notes:**
- This avoids N+1 queries and matches the subscription enforcement logic used elsewhere.

## 2026-02-16 — Phase 7H8 (Ops checks + idempotency scan + timer defaults)
**Shipped:**
- Added staff-only **Ops Checks** page (`/ops/checks/`) to run:
  - `ez360_smoke_test`
  - `ez360_invariants_check`
  - `ez360_idempotency_scan`
- Added `ez360_idempotency_scan` command to detect missing/duplicate journal provenance (NULL-safe uniqueness).
- Timer selections now persist in `TimeTrackingSettings` (`last_project`, `last_service_*`, `last_note`) and are used to rehydrate `TimerState` if it’s recreated.

**Why:**
- Corporate-grade ops requires UI access to evidence-producing checks.
- TimerState is a OneToOne row and can be recreated; defaults guarantee user continuity.

**Next:**
- Provenance audit across all posting sources to guarantee every auto-post sets `JournalEntry.source_type/source_id`.
- Add run history for Ops Checks (who/when/output summary).

## 2026-02-16 — Phase 7H6 (Timer persistence + clear action)
**Shipped:**
- Timer now **remembers last project/service/note** after stopping (no longer clears selections).
- Added **Clear selections** action (POST) for users to reset timer fields intentionally.
- Fixed timer templates/context so `can_manage_catalog` is consistently available (navbar + timer page).

**Why:**
- Corporate UX expectation: frequent time tracking should not require re-selecting the same project/service repeatedly.

**Next:**
- Persist last-used selection defaults into a lightweight per-employee preference record (optional if we keep using TimerState as the source of truth).
- Extend invariants to cover posting idempotency across all posting sources and surface failures in Admin “Ops Checks”.

## 2026-02-16 — Phase 7H4 (Admin money + invariants + timer catalog link)
**Shipped:**
- Fixed remaining admin money displays in CRM, Payables, Payments, and Accounting (no raw cents shown).
- Expanded `ez360_invariants_check` to validate refund sanity and journal provenance.
- Timer UI now includes a quick link to manage catalog services (Manager+).

**Notes:**
- Refund invariants validate `refunded_cents` range and compare to sum of succeeded refunds (warn on mismatch for legacy rows).

## 2026-02-16 — Phase 7G5 (Money UX normalization for Projects & Documents)

**Done:**
- Standardized money inputs to **dollars in the UI** while storing **integer cents** in the database using `core.forms.money.MoneyCentsField`.
- Projects:
  - `ProjectForm` now edits `hourly_rate_cents` and `flat_fee_cents` directly via `MoneyCentsField` (no float/Decimal drift).
  - Updated `templates/projects/project_form.html` to match new field names.
- Documents:
  - `LineItemForm` now edits `unit_price_cents` and `tax_cents` via `MoneyCentsField`.
  - Fixed line total computations to use cents inputs.
  - Updated `templates/documents/document_edit.html` to match new field names.
- Templates:
  - Added `money` filter alias (same as `money_cents`) in `core/templatetags/money.py` so existing `|money` usage renders correctly.

**Notes / follow-ups:**
- Continue rolling the same money UX standard across any remaining modules still using ad-hoc Decimal “*_dollars” helpers.
- Add/expand invariant tests to ensure no cents↔dollars regressions in document totals and project billing rates.

## 2026-02-15 — Phase 7G (Unified private media access + previews)
**Done:**
- Implemented shared private-media access helper: `core/services/private_media.py`
  - Normalizes storage keys (handles storage.location prefixes).
  - Generates presigned **download** URLs (attachment) and **preview** URLs (inline) for PDFs/images.
  - Centralizes content-type guessing and previewability rules.
- Added S3 presign helper for inline preview: `core.s3_presign.presign_private_view()`.
- Updated private-media open endpoints to use shared helper (consistent behavior across modules):
  - Expense receipts: `expenses:expense_receipt_open` supports `?preview=1`
  - Project files: `projects:project_file_open` supports `?preview=1`
  - Bill attachments: `payables:bill_attachment_download` supports `?preview=1`
- Added template filter `previewable` (`core/templatetags/file_extras.py`) and UI links:
  - Bills: Preview button shown for previewable attachments
  - Project files: Preview button shown for previewable non-Dropbox files
  - Expenses: Preview button shown for previewable receipts

**Notes / Behavior:**
- Preview is only enabled for PDFs and common image types; otherwise links fall back to download.
- Authorization remains enforced by existing module views; we do not expose raw bucket URLs in templates.

**Next:**
- Phase 7H: expand A/P payments workflow (checks / vendor credits / payment batches) if pursuing QuickBooks parity, plus reconciliation UI updates.


## 2026-02-15 — Phase 7F (Recurring Bills / A/P)
**Done:**
- Added `payables.RecurringBillPlan` with frequency (weekly/monthly/yearly), `next_run`, `is_active`, optional `auto_post`, vendor, expense account, and amount.
- Manager UI under Payables:
  - Recurring bills list
  - Create / Edit / Delete
  - **Run now** button to generate a bill immediately and advance the schedule.
- Added recurring bill engine:
  - `payables/services_recurring.py` with safe date math (month rollovers) and schedule advancement.
  - Management command: `python manage.py run_recurring_bills [--company <uuid>]` to generate all due bills (next_run <= today).
- Sidebar updated: “Recurring bills” under Payables.

**Notes / Behavior:**
- Each run generates a new Bill with a single line item (expense account + amount) and recalculates totals.
- If `auto_post` is enabled, the generated bill is posted immediately.
- Schedule advancement uses safe month/year rollover rules.

**Next:**
- Phase 7G: continue payables parity (expanded A/P payments workflow, credits/checks) and improve idempotency/traceability of recurring runs if needed.


## 2026-02-15 — Phase 7E: Private media delete-on-remove + Project file open/delete
- Added best-effort S3 object deletes when removing bill attachments and project files (configurable).
- Implemented missing project file open/delete views and wired project files UI actions.
- Added S3_DELETE_ON_REMOVE setting (default true) to control deletion behavior.


# EZ360PM — Project Snapshot

### 2026-02-16 — Hotfix
- Hotfix: fixed NameError in documents/views.py by importing login_required (makemigrations/system checks import URLConf).

## Snapshot 2026-02-13 — Phase 6D (S3 Direct Uploads + Project File Workflow)

### Shipped
- Implemented presigned POST direct uploads to **private S3 bucket** for:
  - Expense receipts
  - Project files
- Added `storage` app endpoint: `POST /api/v1/storage/presign/` (Manager+ only).
- Added settings/env vars:
  - `S3_DIRECT_UPLOADS`
  - `S3_PRESIGN_EXPIRE_SECONDS`
  - `S3_PRESIGN_MAX_SIZE_MB`
- Project file upload now supports `file_s3_key` (multipart file optional when direct uploads enabled).

### Notes
- Templates already use the direct-upload flow when `USE_S3=1` and `S3_DIRECT_UPLOADS=1`.

## Snapshot 2026-02-14 — Phase 6E (UI Polish + Timer Navbar + Dollar Inputs)

### Shipped
- **CRM**: Client “State” now uses consistent Bootstrap select styling (matches the rest of the form).
- **Projects**:
  - Project `__str__` now renders as `P-00001 · Project Name` (fixes “Project object …” dropdown labels across the app).
  - Hourly rate + flat fee are now entered in **dollars** (`$xx.xx`) and converted to cents internally.
- **Time Tracking**:
  - Timer is now accessible from the **top navbar** as a dropdown (start/stop + project + service + notes).
  - Timer start no longer asks for both client + project; **client is derived from the selected project**.
  - Timer stop now creates an optional single service row consuming the full duration (when selected/typed).

## Snapshot 2026-02-14 — Phase 6G (Ops SLO Dashboard + Presence Pings + Optional Alert Webhook)

### Shipped
- Added lightweight **User Presence** tracking (best-effort, throttled per session) to support staff SLO visibility.
  - Middleware: `core.middleware.UserPresenceMiddleware` (writes at most once per minute per session).
  - Model: `ops.UserPresence` keyed by `(user, company)` with `last_seen`.
- Added staff-only **SLO Dashboard** in Ops:
  - `/ops/slo/` showing active users (5m/30m), open alert counts (webhook/email/auth), and per-company active user breakdown.
- Added optional **external webhook notification** for ops alerts:
  - Env: `OPS_ALERT_WEBHOOK_URL` (best-effort POST JSON)

## Snapshot 2026-02-15 — Phase 6J (Production Staticfiles Hardening)

### Shipped
- Added **WhiteNoise** to serve `/static/` reliably in production (Render), including Django Admin assets.
- Switched static storage to `CompressedManifestStaticFilesStorage` for hashed + compressed assets.
- Added env var `WHITENOISE_MANIFEST_STRICT` (default 1) for emergency recovery if `collectstatic` does not run.
  - Env: `OPS_ALERT_WEBHOOK_TIMEOUT_SECONDS`

## Snapshot 2026-02-15 — Phase 6L (S3 Backup Target + Backup Freshness Launch Check)

### Shipped
- Added optional **S3 backup target** for database dumps:
  - Env: `BACKUP_STORAGE=s3`, `BACKUP_S3_BUCKET`, `BACKUP_S3_PREFIX`
  - `ez360_backup_db` uploads the generated `.sql.gz` to S3 and records bucket/key/sha256 in `BackupRun.details`.
  - `ez360_prune_backups --storage s3` prunes old S3 backup objects using the same retention rules.
- Ops → Backups now supports staff-only **Run backup now** and **Prune old backups** buttons.
- Launch Checks now include **Recent successful backup recorded** (required only when `BACKUP_ENABLED=1`).

### Notes
- S3 backup upload uses `boto3` (added to requirements).
- Ops Alerts are raised automatically when a backup run fails (best-effort).

## Snapshot 2026-02-14 — Hotfix (Render migration: Billing index rename)

### Shipped
- Fixed production migration failure on Render:
  - Error: `relation "billing_com_plan_int_status_idx" does not exist`
  - Cause: `migrations.RenameIndex(...)` fails hard when the *old* index name is missing.
- Updated `billing/migrations/0003_...` to be **idempotent** using `SeparateDatabaseAndState`:
  - DB operation uses `RunSQL` with `to_regclass(...)` guards:
    - Renames old→new only when old exists and new doesn’t.
    - Creates the expected indexes if neither exists.
  - State operation preserves `RenameIndex` so Django’s migration graph stays consistent.

## Snapshot 2026-02-13 — Phase 3U (UX Perf Polish: Pagination + CSP)

### Shipped
- Standardized list pagination via `core.pagination.paginate` and applied it to:
  - Clients, Projects, Documents, Payments, Expenses, Merchants, Time Entries, Team.

## Snapshot 2026-02-15 — Phase 6O2 (Pagination Crash Fix After CSV Import)

### Shipped
- Fixed a production 500 on `/clients/` caused by templates evaluating `page_obj.previous_page_number` / `next_page_number` even when the pager UI was disabled.
  - Django raises `EmptyPage: That page number is less than 1` when `previous_page_number()` is called on page 1.
- Hardened shared pagination include (`templates/includes/pagination.html`) to only resolve page-number methods when `page_obj.has_previous/has_next`.
- Hardened Audit event list pagination similarly.

### Result
- Client list (and any view using the shared pagination include) renders reliably on first/last pages.
- Added shared pagination UI partial: `templates/includes/pagination.html`.
- Added querystring helper template tag: `{% qs_replace %}` in `core.templatetags.querystring`.

### Security / CSP fix
- Fixed CSP configuration so it correctly works with `core.middleware.SecurityHeadersMiddleware`:
  - `SECURE_CSP` is now the policy (dict/string), and `SECURE_CSP_REPORT_ONLY` is a **bool**.
  - Added env flags:
    - `EZ360_CSP_ENABLED` (default ON in production)
    - `EZ360_CSP_REPORT_ONLY` (default ON in production; turn OFF to enforce)
- Updated policy allowlist to support Bootstrap + Icons via jsDelivr CDN.

### Notes
- The Clients list header “Showing X clients” is now page-scoped (X = current page rows) rather than a global count.

## Snapshot 2026-02-13 — Phase 3R (Security Defaults)

### Shipped
- Email verification gate is now **default ON in production** (DEBUG=False) unless explicitly overridden via `ACCOUNTS_REQUIRE_EMAIL_VERIFICATION`.
- Production security defaults are now **default ON in production** unless overridden:
  - `SECURE_SSL_REDIRECT`, `SESSION_COOKIE_SECURE`, `CSRF_COOKIE_SECURE`, `SECURE_HSTS_SECONDS`.
- New company onboarding defaults to **require 2FA for managers/admins/owners** in production (override via `COMPANY_DEFAULT_REQUIRE_2FA_ADMINS_MANAGERS`).

### Notes
- Local/dev remains relaxed by default (DEBUG=True), but you can flip any behavior via env vars.


## Snapshot 2026-02-13 — Phase 3J (Client Credit Ledger + Auto-Apply)

**Baseline:** user-provided ZIP `de775a36-ff2c-4581-9bbd-1725e308de24.zip`.

### Shipped
- Client credit **application** flow (apply stored client credit to invoices).
- New model `payments.ClientCreditApplication` with indexes and admin registration.
- Invoice stored balance recompute now accounts for:
  - successful payments
  - posted credit notes (A/R applied)
  - applied client credits (credit applications)
- Credit notes that generate **customer credit** now also create a credit ledger entry (+delta) and sync client rollup.
- Invoice edit page now shows:
  - Client Credit card (available credit + apply form)
  - Credit notes table using dollar formatting
- Accounting posting for credit applications: DR Customer Credits / CR A/R (idempotent).

### Notes
- Rollup `Client.credit_cents` is treated as a cached value; ledger is source of truth.

Snapshot Date: 2026-02-13
Baseline: ez360pm_phase3a_layer2.zip

---

# ✅ Completed Phases

## Phase 1 – Security Hardening
- Email verification gate after login
- 2FA enforcement scaffolding (role-based)
- Progressive account lockout
- Security headers middleware
- Support mode (audited, read-only)

## Phase 2 – Production Hardening
- HTTPS enforcement
- Secure cookies (Lax, HttpOnly)
- Stripe environment separation
- Health endpoint
- Backup command scaffolding
- Monitoring toggles (Sentry-ready)

## Phase 3A – Financial Integrity (Layer 1 & 2 ONLY)
- Journal repost prevention (no mutation after initial post)
- Invoice financial field lock after SENT
- Line item lock after SENT
- Status downgrade protection
- Paid invoices fully immutable

---

# ❌ NOT IMPLEMENTED (Intentionally Rolled Back)

- CreditNote model (not production-integrated)
- Reconciliation dashboard
- Balance recalculation refactor
- Journal reversal workflow
- Admin UI financial locking polish

---

# Current Status

EZ360PM now enforces:
- Financial immutability on invoices
- No journal mutation
- Safe status transitions

Accounting core is protected.
Advanced corrective workflows pending.



## 2026-02-13 — Phase 3B Stage 1 (Proper)
- Fixed Phase 3A implementation defects (added real model-level invoice immutability + journal freeze).
- Added CreditNote model (Draft/Posted) + admin registration.
- Added migration merge for dual 0004 documents migrations + CreditNote migration.


## 2026-02-13 — Phase 3G (Backup & Recovery)
- Added `ez360_backup` management command (Postgres dump + optional media archive) with retention pruning.
- Added soft-delete guardrails: default deletes on SyncModel subclasses are tombstones unless `hard=True`.
- Added runbook: `docs/BACKUP_RECOVERY.md`.


## 2026-02-13 — Phase 3H (Monitoring & Observability)
- Added DB-verified health endpoint (`/healthz`), request IDs, and slow-request logging.
- Added optional Sentry integration (safe if dependency missing).
- Improved error logging around Stripe webhooks and email delivery.
- Added runbook: `docs/MONITORING.md`.


## 2026-02-13 — Phase 3I (UX & Premium Experience)
- Dashboard upgraded to a **guided onboarding checklist** (progress bar + "Next" CTA) based on live company data.
- Alerts upgraded to dismissible Bootstrap alerts; Django's `error` tag maps to `danger`.
- Fixed an internal defect introduced in Phase 3G: removed duplicate `soft_delete` method definition.

- 2026-02-13: Added CreditNote posting service (Draft → Posted) with immutable JournalEntry creation and audited event logging.
- Admin action: Post selected credit notes.


## Phase 3C (implemented)
- 2026-02-13: Credit note allocation fields added (AR applied vs customer credit).
- 2026-02-13: Payment recalculation now subtracts posted credit notes for balance_due_cents, while invoice status remains payment-driven.
- 2026-02-13: Accounting reconciliation dashboard added (/accounting/reconciliation/).

- 2026-02-13: Phase 3D added Credit Note UI (create draft + post), invoice edit credit note section, and admin read-only locks.

- 2026-02-13: Phase 3E tightened credit note permissions, added safer invoice gating (must be SENT+), money formatting via cents_to_dollars, reconciliation link, and credit note numbering sequence CN-YYYYMM-####.

- 2026-02-13: Phase 3F added draft-only credit note edit UI, dollar-based inputs, invoice activity timeline (audit events), and improved invoice edit credit note interactions.

- 2026-02-13: Phase 3F added draft-only credit note edit view, dollars-based credit note form (store cents internally), invoice timeline (audit events), and stronger UI clarity.

- 2026-02-13: Phase 3G added backup & recovery tooling: `ez360_backup` management command (Postgres pg_dump + optional media tarball), retention pruning settings (EZ360_BACKUP_DIR/RETENTION_DAYS/KEEP_LAST), and documented restore procedure in docs/BACKUP_RECOVERY.md. Also added soft-delete guardrail by making SyncModel.delete() default to tombstoning via deleted_at.


## Phase 3H (Monitoring & Observability Pack) — Completed
- Added request id middleware (X-Request-ID).
- Added /healthz endpoint (DB-verified) and updated legacy /health/ to match.
- Added slow request logging with env threshold.
- Added optional Sentry integration in production settings (safe if dependency absent).
- Improved webhook + email failure logging (and Sentry capture when available).
- Added docs/MONITORING.md and updated ENV_VARS.md.

## 2026-02-13 — Phase 3J+ (Subscription Tiers + Feature Gating)

- Updated subscription tiers to match Stripe plan model:
  - Starter ($19/mo or $190/yr) — 1 included seat
  - Professional ($49/mo or $490/yr) — 5 included seats (includes Accounting engine)
  - Premium ($99/mo or $990/yr) — 10 included seats (advanced reporting, future API/Dropbox)
  - Extra seats add-on ($10/mo or $100/yr per seat) tracked as subscription item quantity.
- Implemented tier-aware gating:
  - `billing.decorators.tier_required(min_plan)` decorator.
  - `billing.services.plan_allows_feature(feature_code)` centralized feature rules.
- Enforced tier gating in the app:
  - Accounting module is Professional+.
  - Dropbox Integration module is Premium-only (pre-wired for future rollout).
- Stripe integration updated for the new tier model:
  - Checkout expects (plan + billing interval) instead of plan+seat-tier.
  - Webhook sync best-effort infers plan/interval/extra_seats from subscription metadata and/or price lookup_keys.
- Billing UI updated:
  - Plan = Starter/Professional/Premium + Monthly/Annual
  - Seat limit computed as included + extra seats

## 2026-02-13 — Phase 3K: Ops Console + Support Mode UX
- Added new internal staff-only Ops Console at /ops/ with company search, subscription overview, seat counts, and company detail view.
- Ops Console can enter Support Mode for a target company and sets active company in session.
- Sidebar now shows Staff section (Ops Console + Support Mode) for is_staff users.


## 2026-02-13 — Phase 3L (Ops Timeline + Subscription Diagnostics)
- Added staff-only company timeline view combining Audit events + Stripe webhook processing events.
- Added staff-only “Resync from Stripe” action (fetch subscription from Stripe API and sync CompanySubscription).
- Ops company detail now shows best-effort matched recent webhook events for the company.
- Added Stripe fetch+sync helper in billing.stripe_service (uses Stripe API; requires STRIPE_SECRET_KEY + stripe package).

## 2026-02-13 — Hotfix: Ops Support Mode import
- Fixed ops.views import/call to use core.support_mode.set_support_mode (previously referenced non-existent enable_support_mode).


## Phase 3M – Refund Linkage (Payments)
- Added PaymentRefund model + admin.
- Added refund workflow: manager can create a refund (Stripe best-effort) from payment edit screen.
- Refunds roll up into Payment.refunded_cents and adjust invoice balances (net payments).
- Accounting: added payment_refund journal entries reversing cash/AR/credits based on original payment allocation.


- 2026-02-13: Phase 3O advanced reporting: CSV exports for accounting reports + Premium Project Profitability report.

## 2026-02-13 — Phase 3P: Launch Readiness Checks
- Added staff-only Launch Checks page (Ops) that runs a lightweight production checklist (security, Stripe, email, static, Sentry optional).
- Added management command: `python manage.py ez360_check` (non-zero exit if errors).
- Added sidebar link (Staff → Launch Checks).

## 2026-02-13 — Phase 3Q: Ops Retention & Pruning
- Added env-driven retention controls:
  - `EZ360_AUDIT_RETENTION_DAYS` (default 365)
  - `EZ360_STRIPE_WEBHOOK_RETENTION_DAYS` (default 90)
- Added management command: `python manage.py ez360_prune` (dry-run by default; use `--execute` to delete).
- Added staff-only Ops page: /ops/retention/ with prune-now button and dry-run eligible counts.

## 2026-02-13 — Phase 3S (Financial Integrity + Reconciliation)

- Added **Invoice Reconciliation** page to help diagnose invoice balances (payments, refunds, credit notes, client credit applications) and provide a one-click **Recalculate** action.
- Hardened accounting journaling: journal lines are now **write-once** (no mutation once posted) and entries must be balanced.
- Fixed `DocumentLineItem.__str__` placement (was a stray global function).

## 2026-02-13 — Phase 3T: Ops Alerts + Session Hardening

- Added best-effort ops alert emails for **Stripe webhook** failures and **email** delivery failures (controlled by env defaults ON in production).
- Added session key rotation on successful password login.
- Added `core.ops_alerts.alert_admins()` helper.

## 2026-02-13 — Phase 3U: Pagination + CSP

- Added shared pagination helpers (helper, querystring tag, pagination partial) and applied pagination across major list pages.
- Fixed CSP settings typing and added rollout toggles (report-only defaults in production).

## 2026-02-13 — Phase 3V: Performance Indexing

- Added missing DB indexes for Payments and client credit ledger/application tables.
- Fixed `ClientCreditApplication` index declaration (previously not in Meta; indexes were not being created).

## 2026-02-13 — Phase 3W: Lightweight Perf Checks + Documents/TimeEntry Indexes

- Added dev-only **PerformanceLoggingMiddleware** (logs slow requests + slow ORM queries; thresholds are env-driven).
- Added `python manage.py perf_check` management command to run and time the core list querysets for **Documents** and **TimeEntry**, reporting query counts and slowest SQL.
- Added Postgres partial indexes (ignoring soft-deleted rows) to speed up common list filters:
  - Documents: (company, doc_type, created_at) and (company, doc_type, status, created_at) where deleted_at IS NULL
  - TimeEntry: (company, status, started_at), (company, employee, status, started_at), (company, billable, started_at) where deleted_at IS NULL

## 2026-02-13 — Phase 3X: Settings Profiles Fix (Dev/Prod Separation)

- Fixed a settings architecture issue that made **dev mode unreliable**:
  - Removed an accidental “settings shim” behavior from `config/settings/base.py` that was importing `dev` inside `base` and overriding values.
  - Removed hard-coded `ALLOWED_HOSTS` that forced production hosts even in local dev.
- Re-established the intended pattern:
  - `base.py` contains shared settings only.
  - `dev.py` and `prod.py` override environment-specific behavior.
- Added `apply_runtime_defaults()` in `base.py` for settings derived from `DEBUG` (email verification defaults, security cookie defaults, CSP rollout defaults, etc.).
  - `dev.py`/`prod.py` now re-run it after setting `DEBUG` so defaults stay consistent.
- Cleaned up `prod.py` duplicate/invalid logging definition and fixed the formatter string.

## 2026-02-13 — Phase 3Y: Dev HTTP/HTTPS Access Fix

- Fixed a dev usability issue where local development could be forced into HTTPS redirects due to production-style env values.
- `config/settings/dev.py` now defaults to **HTTP** (no SSL redirect) regardless of `SECURE_SSL_REDIRECT` in the environment.
- Optional local HTTPS testing is now explicit via `DEV_SECURE_SSL_REDIRECT=1` (requires an HTTPS-capable local server).

## 2026-02-13 — Phase 4A: Monitoring & Observability

Phase 4A — Monitoring & Observability

- Added public health check endpoint: `GET /healthz/` (includes DB + cache checks).
- Centralized Sentry initialization via `init_sentry_if_configured()` in `config/settings/base.py` and called from `dev.py` and `prod.py`.
- Updated `.env.example` to be a complete, copy/paste-ready reference for all required environment variables (dev + prod), including Phase 4 monitoring vars.

## 2026-02-13 — Phase 4B: Ops Alerts + Perf Sampling (DB-backed)

- Added DB-backed ops alerts (`ops.OpsAlertEvent`) with a staff-only **Ops Alerts** page:
  - Filters by status (open/resolved), source, level, and search.
  - Acknowledge/resolve workflow.
  - Quick KPIs for open webhook/email/perf alerts.
- Stripe webhook failures now generate DB alerts (signature invalid and processing exceptions) in addition to best-effort admin email alerts.
- Email send failures now generate DB alerts (in addition to optional admin email alerts + Sentry capture).
- Performance logging middleware can optionally store sampled **slow request** alerts to the DB (no SQL stored), controlled via env/settings:
  - `EZ360_PERF_LOGGING_ENABLED`
  - `EZ360_PERF_REQUEST_MS`
  - `EZ360_PERF_SAMPLE_RATE`
  - `EZ360_PERF_STORE_DB`

## 2026-02-13 — Phase 5A: UX & Premium Experience (Getting Started)

- Added a dedicated **Getting started** page (`/getting-started/`) with the computed onboarding checklist + quick actions.
- Added a **Getting started** link to the left sidebar with a progress badge when setup is incomplete.
- Added a lightweight onboarding progress computation to the global app context (uses `.exists()` checks).


## 2026-02-13 — Phase 5B: UX defaults + empty states
- Added Company financial defaults (invoice due days, estimate valid days, sales tax percent guidance, default taxable checkbox).
- On company onboarding, provisioned defaults: numbering scheme, minimal chart of accounts, and default document templates.
- Document wizard now sets sensible default dates (issue date + due/valid dates).
- Document line item form defaults Taxable checkbox using company default.
- Improved list-page empty states (clients, projects, documents, time, payments) with clear actions.


## 2026-02-13 — Phase 6A: Launch Readiness Gate + Ops Security
- Added Ops **Security** page (staff-only): recent account lockouts + auth/throttle ops alerts.
- Added Ops **Launch Gate** checklist (staff-managed) with seed items matching the hardening outline.
- Added `python manage.py ez360_smoke_test --company-id <id>` command to validate the end-to-end flow in dev/staging (DB-only, no Stripe).
- Added ops alert hooks:
  - Throttle blocks create Ops alerts (source=throttle).
  - Login blocked due to lockout creates Ops alerts (source=auth).


## Phase 6B — Invoice immutability hardening + reconciliation console (2026-02-13)

- Strengthened **invoice immutability**:
  - Invoices are now considered **locked** once **Sent**, **Partially Paid**, **Paid**, or if any **payments / client credit applications / posted credit notes** exist.
  - Locked invoices reject changes to: client/project, dates, and all money fields (subtotal/tax/total).
  - Locked invoices reject **line item create/update/delete** (including soft-delete).
  - Added `InvoiceLockedError` for explicit failures.
  - UI: invoice edit page shows a clear “Invoice locked” banner; POST edits are blocked at the view layer too.

- Added **Ops → Reconciliation** page (staff-only):
  - Company selector + snapshot metrics for invoices/payments/credits.
  - Practical flags: AR vs invoice balances, customer credits vs credit ledger, payments vs invoice paid drift.
  - Shows accounting account balances (AR 1100, Cash 1000, Customer Credits 2200) when accounting is enabled.

- Fixed a real bug in payment audit logging:
  - `prev_balance` was referenced before assignment in `apply_payment_and_recalc`; now captured correctly.

- Smoke test upgraded:
  - `python manage.py ez360_smoke_test --company-id <id>` now validates that locked invoices reject document and line-item mutations.

Files touched (high level):
- `documents/models.py`, `documents/views.py`, `templates/documents/document_edit.html`
- `ops/views.py`, `ops/urls.py`, `ops/services_reconciliation.py`, `templates/ops/reconciliation.html`, `templates/ops/dashboard.html`
- `payments/services.py`
- `core/management/commands/ez360_smoke_test.py`
- `accounting/models.py` (missing ValidationError import)

## 2026-02-13 — Phase 6C: Backups/Restore Visibility + Recording (Ops)
- Added Ops → Backups page for configuration visibility and recording backup runs + restore tests.
- Added BackupRun and BackupRestoreTest models (staff/audit use).
- Added BACKUP_* env vars (safe defaults; dev forces disabled unless DEV_BACKUP_ENABLED).

## 2026-02-13 — Phase 7A: Release Discipline (Build Metadata + Preflight)
- Added public `GET /version/` endpoint returning safe build info (environment/version/sha/date).
- Added build metadata settings: APP_ENVIRONMENT, BUILD_VERSION, BUILD_SHA, BUILD_DATE.
- Launch checks now warn in production if build metadata is missing.
- Added management command `python manage.py ez360_preflight` (Django checks + launch checks) for CI/staging/prod.
- Updated `.env.example` to include build/release variables.


## 2026-02-13 — Phase 7B: Release Notes + Preflight Migration Guard
- Added Ops → Releases page with staff-maintained release notes tied to build metadata.
- Added ReleaseNote model + admin registration.
- Enhanced ez360_preflight to detect pending migrations and fail (configurable via PREFLIGHT_REQUIRE_NO_PENDING_MIGRATIONS).


## 2026-02-13 — Phase 7C: Request-ID logging + production security checks
- Added request-id aware base LOGGING with `core.logging.RequestIDLogFilter` and standard console formatter.
- Updated prod logging to inherit base and include key app loggers.
- Added launch checks for secure cookies and HSTS (warn-level; dev-safe).


## 2026-02-13 — Phase 6D: Backup Automation Command

- Added `python manage.py ez360_backup_db` to run `pg_dump` backups (Postgres only) and record `ops.BackupRun` success/failure.
- Added env vars: `EZ360_PG_DUMP_PATH` (optional), plus documented backup flags in `.env.example`.
- Dev remains safe: backups are disabled unless enabled via env (`BACKUP_ENABLED=1` or `DEV_BACKUP_ENABLED=1`).

## Phase 3E / 6E – Backup retention pruning (command)
- Added `python manage.py ez360_prune_backups` to enforce retention by age and optional max-count.
- Added env var `BACKUP_MAX_FILES` and documented it.
- This complements `ez360_backup_db` and the Ops Backups evidence UI.


## 2026-02-13 — Phase 6F: Backup scheduling guidance + restore-test helper
- Added `python manage.py ez360_record_restore_test` to record restore test evidence from CLI.
- Documented host scheduling (cron/Task Scheduler) for `ez360_backup_db` + `ez360_prune_backups`.
- Updated backups Ops UI with scheduler guidance.


## 2026-02-13 — Soft-delete guardrails + optional S3 media storage

- **Soft-delete guardrails**: `SyncModel` now uses a default manager that hides `deleted_at` rows (`objects`) and exposes `all_objects` for admin/maintenance.
  - Added `SyncQuerySet.delete()` bulk soft-delete guardrail.
  - Admins now include soft-deleted rows via `IncludeSoftDeletedAdminMixin` (Documents, Payments/Credits, Clients/Vendors, Projects, Time Entries).
- **Media storage strategy**: added optional S3/S3-compatible media storage configuration via `STORAGES` + `USE_S3` env var (requires `django-storages[boto3]` when enabled).
  - Added docs: `docs/MEDIA_STORAGE.md`
  - Updated `.env.example` and `docs/ENV_VARS.md`



## 2026-02-13 — Phase 6C: Reconciliation Drift Toolkit + S3 Multi-Bucket Storage
- Added Ops Drift Toolkit (/ops/drift/) with staff actions: recalc invoice rollups, post missing accounting entries, and link orphan payment → invoice.
- Implemented S3 multi-bucket media storage via core.storages: public bucket (logos/general) + private bucket (receipts/project files).
- Updated .env.example, ENV_VARS, MEDIA_STORAGE docs.


## 2026-02-13 — Phase 6C.1: Private downloads (signed URLs) + receipt download route
- Private media (receipts/project files) now uses **presigned S3 URLs** via `PrivateMediaStorage(querystring_auth=True)`.
- Added `expenses:expense_receipt_open` route to gate receipt access and then redirect to the presigned URL.
- Updated UI to show a paperclip action on expenses with receipts.
- Added env var: `S3_PRIVATE_MEDIA_EXPIRE_SECONDS`.

## 2026-02-13 — Phase 6D: Direct-to-S3 uploads + project file secure workflow

- Added Storage API endpoint: `POST /api/v1/storage/presign/` (Manager+) to generate **presigned POST** policies for private bucket uploads.
- Implemented **direct-to-S3 uploads** in UI for:
  - Expense receipts (expense form)
  - Project files (project files page)
  - Browser uploads to S3 first, then submits the object key to the app.
- Added env vars: `S3_DIRECT_UPLOADS`, `S3_PRESIGN_MAX_SIZE_MB`, `S3_PRESIGN_EXPIRE_SECONDS`.
- Updated docs: `docs/MEDIA_STORAGE.md` includes AWS CORS example for private bucket.

## 2026-02-14 — Phase 6F: Service Catalog integration + navbar live timer + pause/resume

- Project create/edit **Services** section is now table-based and looks intentional.
- Project services now use **CatalogItem (Service)** dropdowns (company-scoped, active only) with optional custom service names.
- Navbar timer now shows **project + live elapsed time** and provides **pause/resume** without opening the dropdown.
- Timer supports pause/resume using persisted `elapsed_seconds` + `is_paused`/`paused_at` fields.

## 2026-02-14 — Phase 6F.2: Render error-page hotfix (missing _public_shell.html)

- Added `templates/_public_shell.html` as a compatibility shim so `404.html` and `500.html` can render reliably.
- Prevents error-handler recursion on production if a server error occurs during public flows.

## Snapshot 2026-02-14 — Render Hotfixes (Migrations + Templates + Email Verify Resend)

### Fixed
- **Billing migration 0003** made idempotent for production DBs where the prior index name does not exist (guards rename/create).
- Restored compatibility template **`templates/_public_shell.html`** so error pages render in production.
- Updated **404/500** templates to link to the public home route (removed broken `dashboard:` namespace).
- Fixed **verify-email resend routing** by placing `verify-email/resend/` before `verify-email/<token>/` to prevent “resend” being treated as a token.
- Added `@login_required` + Ops alert on resend email failure (best-effort; never blocks user flow).


## 2026-02-14 — Phase 6H (Ops: PII Export + SLO webhook freshness)
- Added staff-only PII export: /ops/pii-export/ exports company data to CSV ZIP (clients/projects/documents/payments/expenses/time entries).
- Enhanced SLO dashboard with Stripe webhook freshness (last received/last ok + failures last 24h).

## 2026-02-14 — Phase 6I (Security: 2FA enforcement for Admin/Owner)
- Login now supports 2FA-enabled accounts: password auth creates a pending 2FA challenge and redirects to `/accounts/2fa/verify/`.
- Added session-scoped 2FA marker with TTL (`TWO_FACTOR_SESSION_TTL_SECONDS`, default 12h).
- Company-scoped pages enforce 2FA as a step-up gate:
  - Admin/Owner roles are always required to pass 2FA.
  - Company policy flags (`require_2fa_for_all`, `require_2fa_for_admins_managers`) and `employee.force_2fa` also trigger enforcement.
- Added `/accounts/2fa/confirm/` for already-authenticated step-up confirmation.

## 2026-02-15 — UI Shell Responsive + Theme Toggle
- Added first-class EZ360PM brand theme (blue/green) via CSS variables with light/dark modes.
- Implemented light/dark toggle in top navbar (persisted in localStorage; defaults to OS preference).
- Sidebar now scrolls when content exceeds viewport height (no disappearing links).
- On mobile, sidebar collapses into an off-canvas drawer with overlay + hamburger toggle.
- Topbar actions collapse into a mobile menu (three-dots button) to prevent overflow.
- Added Bootstrap JS bundle (CDN) and kept safe fallbacks where needed.
Files: templates/base_app.html, templates/base_public.html, static/ui/ez360pm.css, static/ui/ez360pm.js

## 2026-02-15 — Phase 6J (Render Staticfiles: WhiteNoise)
- Enabled WhiteNoise middleware + compressed manifest static storage so `/static/` serves correctly on Render when `DEBUG=False`.
- Added `whitenoise>=6.7.0` and documented the requirement that `collectstatic` must run during deploy.

## 2026-02-15 — Phase 6K1 (Mobile Topbar Fix + Sentry Init)
- Fixed iOS/mobile topbar overlap by enforcing responsive brand logo sizing (`.ez-brand-logo`) and consistent topbar sizing (`.ez-topbar`) with safe-area insets.
- Public + app shells now use the same topbar classes and brand logo styling.
- Enabled Sentry initialization when configured by calling `init_sentry_if_configured()` after `apply_runtime_defaults()`.

## 2026-02-15 — Phase 6K2 (Timer Dropdown Reliability + Invoice Lock UX)
- Timer navbar widget dropdown is now **JS-driven and Bootstrap-independent** (prevents “click does nothing” on mobile/prod).
  - Removed `data-bs-toggle="dropdown"` from the timer button.
  - Added explicit toggle logic that adds/removes `.show` and closes on outside click / Escape.
- Locked invoices now render in **read-only mode** on the edit screen:
  - All fields/line-items are disabled.
  - The Save button becomes a disabled “Locked” button.
  - Context now passes `is_locked` + `lock_reason` for consistent messaging.

### 2026-02-15 — Phase 6M1
- Ops Launch Checks expanded: verifies WhiteNoise static config + adds smoke checks for core data presence.
- Goal: reduce 'it works locally' drift by surfacing config and workflow readiness in a single screen.

### 2026-02-15 — Phase 6N (Ops Email Diagnostics)
- Added **Ops → Email test** (staff-only) to send a real test email and record results.
  - Stores an audit row per attempt (SENT / FAILED) including backend, from address, latency, and error text.
  - Failures create an Ops Alert (EMAIL / ERROR) for visibility.
- Launch Checks now include:
  - `DEFAULT_FROM_EMAIL` configured check.
  - “Recent successful email test (last 7 days)” evidence check (warns in prod until you run one).

### 2026-02-15 — Phase 6O (Error Page Hardening)
- Fixed `404.html` and `500.html` to avoid invalid URL namespaces and link to the stable `home` route.
- Added request correlation to error pages (shows Request ID when available).
- Hardened `core/error_views.py` so error templates never recurse (fallback to minimal HTML if template rendering fails).

### 2026-02-15 — Phase 6O2 (Clients Pagination Hotfix)
- Fixed a production 500 on `/clients/` caused by templates calling `page_obj.previous_page_number` / `next_page_number` when on the first/last page.
- Updated the clients list template to guard prev/next rendering via `has_previous/has_next`.

### 2026-02-15 — Phase 6P (Monitoring Gate: Ops Probes)
- Added **Ops → Probes** page with staff-only tools to validate monitoring in each environment.
  - **Test error**: intentionally raises a 500 and records an `OpsProbeEvent` (used to confirm Sentry captures exceptions).
  - **Create test alert**: creates an INFO Ops alert (source=PROBE) and records an `OpsProbeEvent`.
- Launch Checks now require evidence of a Sentry test error within the last 30 days when `SENTRY_DSN` is configured.


## 2026-02-15 — Pack: Optional 2FA enforcement + Client email index
- Changed 2FA enforcement: no longer forced by role; enforced only via Company/Employee admin flags.
- Company default 2FA enforcement now defaults to OFF unless env explicitly enables it.
- Added DB index for Client(company, email) + migration (crm 0002) to improve search/import performance.


## Hotfix (2026-02-15)

- Fixed getting-started crash by adding back-compat URL name `documents:numbering` (aliases to Document settings).

## 2026-02-15 — Phase 6O.3: UI reliability polish
- Hardened mobile navigation UX:
  - Sidebar now locks body scroll when open and auto-closes on link click (mobile/tablet).
  - Switching to desktop breakpoint closes any open drawers automatically.
- Sidebar Company switcher dropdown no longer depends on Bootstrap JS; uses deterministic dropdown toggle.


## 2026-02-15 — Phase 6O.4: Accessibility polish
- Added skip-to-content link and focus-visible styling.
- Improved keyboard behavior for custom dropdown toggles.

## 2026-02-15 — Phase 6R.1: Reconciliation affordance + perf micro-hardening
- Added a **Reconcile** button on the invoice edit screen (Manager+) linking to `payments:invoice_reconcile`.
- Reduced memory usage for staff-scoped Clients list by keeping `id__in` as a DB subquery (no Python `list()` materialization).


### Phase 6S (2026-02-15)
- Adjusted 2FA enforcement: no implicit role-based forcing; enforcement is only via Company policy flags (`require_2fa_for_all`, `require_2fa_for_admins_managers`) or `employee.force_2fa`.
- Added Projects DB indexes for common filters/sorts: (company, assigned_to), (company, client), (company, updated_at).

## 2026-02-15 — Phase 6T: Accounts Payable (MVP)
- Added new **payables** app with Vendor + Bills + Bill line items + Bill payments.
- Bills have a Draft → Posted lifecycle; posted bills are locked for edits.
- Posting a bill creates an accounting Journal Entry (`source_type='bill'`) that debits expense accounts and credits **Accounts Payable**.
- Recording a bill payment creates a Journal Entry (`source_type='bill_payment'`) that debits **Accounts Payable** and credits the selected cash/bank account.
- Added sidebar nav entries: **Bills (A/P)** and **Vendors** (manager+).


## 2026-02-15 — Phase 6T.1: Vendor unification + payables dashboard/ledger
- Unified vendor concept: deprecated **crm.Vendor** and migrated data into **payables.Vendor** (UUIDs preserved).
- Expenses now reference **payables.Vendor** so vendors are consistent across payables + expense tracking.
- Added Vendor detail (ledger-style) page: open balance, recent payments, and bill history.
- Added Dashboard Payables card: outstanding payables + due-soon count (7 days).
- Sync registry now includes back-compat mapping for `crm.Vendor` → `payables.Vendor`.

## Snapshot 2026-02-15 — Phase 7C (Payables: A/P Aging + Bill Attachments)

### Shipped
- Added **A/P Aging** report page + CSV export:
  - `GET /payables/reports/ap-aging/`
  - `GET /payables/reports/ap-aging.csv`
- Bills list supports **Due soon** filter (next 7 days).
- Vendor detail “New bill” button now preselects that vendor.
- Added **BillAttachment** model + admin support (stores private `file_s3_key`).
- Bill detail page supports **direct-to-S3 bill attachments** when `USE_S3=1` and `S3_DIRECT_UPLOADS=1`.
- Storage presign supports new kind `bill_attachment` using keys:
  - `private-media/bills/<company_id>/<bill_id>/<uuid>_<filename>`

### Notes
- This pack registers attachments after upload; secure download (presigned GET) is a follow-up pack.

## 2026-02-15 — Phase 7D (Payables): secure bill attachment downloads
- Added `core.s3_presign.presign_private_download()` for private-bucket presigned GET URLs.
- Added `payables:bill_attachment_download` route and UI Download button on Bill detail attachments table.
- Added `S3_PRESIGN_DOWNLOAD_EXPIRE_SECONDS` setting (default 120s).

## 2026-02-15 — Phase 7G.1 Hotfix: Services admin link
- Fixed a production 500 on **/projects/new/** caused by the admin reverse `admin:catalog_catalogitem_changelist` not resolving.
- Root cause: **CatalogItem** existed but was **not registered in Django Admin**, so the admin URL name was missing.
- Added `catalog/admin.py` registration for `CatalogItem` (list/search filters) so “Manage services” link works.

## 2026-02-15 — Phase 7G1 (Help Center wiring + manual skeleton kickoff)
**Done:**
- Added Help Center + Legal routing into `config/urls.py` by including `helpcenter.urls`.
- Updated top-nav Help button to route to `helpcenter:home`.
- Confirmed 2FA policy is **optional** and controlled via company/employee settings (no role-forcing).

**Found during static code check:**
- Help Center existed but was unreachable (not included in root URLs) — now fixed.
- Catalog/services exist (admin) but are not yet first-class UI for non-admin users.
- TimeEntry model still contains both `client` and `project` fields; UX should remain project-driven with client derived.

**Next focus:**
- Expand Feature Inventory into full User Manual (role-by-role, feature-by-feature).
- Add automated smoke/invariant checks beyond `ez360_smoke_test`.
- Corporate polish pass (forms, dollars formatting, email templates, UX consistency, ops readiness).

## 2026-02-15 — Phase 7G2 (Corporate polish: Catalog UI + project-driven time + money helpers)

**Shipped:**
- Added in-app **Catalog** UI (Manager+): list/search/filter + create/edit/delete.
- Added `core.templatetags.money.money_cents` to standardize `$xx.xx` formatting for cent-based amounts.
- Added `core.forms.money` helpers (parse dollars safely; cents conversion).
- Payments: Decimal-safe dollars→cents conversion and $ placeholders.
- Time tracking: enforce project-driven client alignment for `TimeEntry` and `TimerState` (auto-derive client; block mismatch).

**Notes / Follow-ups:**
- Still need to apply money formatting and $-input UX to invoices, expenses, bills, and accounting surfaces.
- Still need to enforce TimeEntry state locks after Approved/Billed.


## 2026-02-16 — Phase 7H (Pack 7H1) — Money UX completion for Expenses/Payables/Payments + smoke-test alignment

**Shipped**
- Standardized **money inputs** to cents-backed `MoneyCentsField` across:
  - Expenses (`ExpenseForm`: `amount_cents`, `tax_cents`)
  - Payables (`BillForm.tax_cents`, `BillLineItemForm.unit_price_cents`, `BillPaymentForm.amount_cents`, `RecurringBillPlanForm.amount_cents`)
  - Payments (`PaymentForm.amount_cents`)
- Updated templates to render dollar inputs consistently using Bootstrap **input-group** `$` prefix.
- Fixed a real template bug in `templates/expenses/expense_form.html` (`{% load static file_extras %}`).
- Updated `ez360_smoke_test` to match project-driven time-entry policy (no separate client selection).

**Why**
- Removes float rounding drift and eliminates mixed “dollars vs cents” UI.
- Moves EZ360PM closer to “corporate-grade” consistency and reduces user mistrust/friction.

**Next**
- Apply money UX standard to any remaining modules displaying raw cents (reports, admin list columns, dashboards).
- Expand smoke/invariant suite: document totals math, partial payments/credits, posting idempotency.


## 2026-02-16 — Phase 7H2
**Context:** Corporate hardening continued after Phase 7H1.

**Changes shipped:**
- Payments: implemented missing `PaymentRefundForm` used by `payments.views` (refund UI functional again).
- Added `manage.py ez360_invariants_check` to validate invoice/payment invariants (totals and paid/balance sanity).
- Documents: improved money-entry UX in line item editors (unit price + tax `$` input groups).
- Documents: removed raw cents debug display from Credit Note post confirmation.

**Notes / Next:**
- Extend invariants to cover credits/credit-notes and journal posting idempotency.
- Add “service on the fly” to the navbar timer dropdown.
- Standardize money rendering across dashboards/admin list columns (use `|money`).

## 2026-02-16 — Phase 7H3 (Invariants + Timer Service Creation + Admin Money Formatting)

**Shipped:**
- Timer: added **“Save as catalog service”** (Manager+) when starting the timer (navbar dropdown + timer page). If checked, typed service name is created as an active **CatalogItem (Service)** and linked to the timer.
- Invariants: expanded `manage.py ez360_invariants_check` to also scan **posted credit notes** (must have journal entry; applied cents in range) and **journal entries** (must be balanced).
- Admin money formatting: formatted money amounts in key Django Admin lists (Payments, Catalog items, Documents) using `format_money_cents`.

**Notes / Next:**
- Standardize remaining admin list displays (Expenses, Payables) and any lingering raw cents in templates.
- Expand invariants further: client credit ledger/application reconciliation; payment refunds vs invoice paid snapshots; posting idempotency audits.

## 2026-02-16 — Phase 7H5 — Invariants suite reliability + client credit sanity

**Code**
- Replaced the previous `ez360_invariants_check` implementation with a clean, sectioned version (Invoices / Payments+Refunds / Client Credits / Journals).
- Added client credit rollup sanity warnings (ledger sum vs `Client.credit_cents`) and credit application integrity checks.
- Added journal balance validation and stronger provenance checks.

**Docs**
- ROADMAP updated with Phase 7H4 and Phase 7H5 completion notes + next steps.
- DECISIONS updated to reflect invariants command scope and CI usage.

**Next**
- Add deeper credit availability checks (requires snapshot or replay approach).
- Add idempotency coverage audit for JournalEntry provenance across all posting sources.
- Add DB-backed “timer last used selections” persistence per employee.

## 2026-02-16 — Phase 7H6 Hotfix (Template Syntax)
- Fixed `templates/base_app.html` timer clear-selections condition (Django templates do not support parentheses in `{% if %}` expressions).



## 2026-02-16 — Phase 7H7 (Accounting Refund Posting Hardening)
- Fixed missing `Sum` import in `accounting/services.py` which broke refund journal posting.
- Hardened payment refund proration logic to use integer math (no float/round drift) when allocating refund between A/R and Customer Credits based on the original payment journal.
- Carried forward from Phase 7H6a hotfix (template-safe timer clear logic).

Next:
- Expand invariants to validate payment-refund journals are balanced and present for succeeded refunds.
- Consider adding a small unit test for refund proration edge cases (all AR vs all credits vs mixed).

## 2026-02-16 — Phase 7H9 — Readiness Check + Ops UI wiring
- Added `ez360_readiness_check` management command (non-destructive): validates env basics, DB connectivity, pending migrations, media storage writability, and email backend connectivity.
- Added Readiness Check option to Ops → Checks UI (staff-only) so launch evidence can be collected without CLI access.
- Updated Ops checks form/view/template wiring to include the new check.


## 2026-02-16 — Phase 7H10 — Email polish + contextual help links

- Fixed SUPPORT_EMAIL defaults in email templates and verification email.
- Email base template footer now references Support email and Help Center.
- Document emails now include support_email in context for consistent branding.
- Added contextual Help buttons to Dashboard, Time, Documents, Bills, and Payments pages.


## 2026-02-16 — Phase 7H11 (Ops Checks History + Options)
- Enhanced Ops Checks UI with Company picker + Quiet/Fail-fast options.
- Added OpsCheckRun model + admin for run history and launch evidence.
- Ops Checks page now shows recent run history with expandable output.

## 2026-02-16 — Phase 7H12 (DONE)
- Timer UX: added "Open selected project" shortcut links in navbar timer dropdown and timer page when a project is selected.
- Docs updated and roadmap advanced to next hardening items.

## 2026-02-16 — Phase 7H13 (Money display unification)
- Standardized currency formatting so all legacy `|cents_to_dollars` outputs now match the corporate standard `$x,xxx.xx`.
- Updated key UI surfaces to prefer `|money` over `|money_cents` (dashboard + catalog list).
- No behavior changes to underlying cents storage; this is display-only polish.


## 2026-02-16 — Phase 7H14 (Email subject standard + Ops evidence export)
- Email subjects are now normalized via `core.email_utils.format_email_subject()` (trim, prefix, optional separator, 200-char cap).
- Ops/alert emails (`core.ops_alerts.alert_admins`) and `ez360_ops_report` now use the subject normalizer to enforce consistent branding.
- Ops Checks output now has a truncation guardrail that appends an explicit "[output truncated]" marker.
- Added staff-only download endpoint for OpsCheckRun output (Ops → Checks → Recent Runs → download).

Next:
- Expand Help Center content with deeper page-by-page walkthroughs and screenshots.
- Add OpsCheckRun CSV export for audit/compliance evidence if needed.

## 2026-02-16 — Phase 7H15 (Ops seat limit fix)
- Fixed Ops dashboard crash by removing direct `subscription.seats_limit` access; seat limits are computed via `billing.services.seats_limit_for(subscription)`.
- Documented the computed-seat policy to prevent regression.

## 2026-02-16 — Phase 7H16 (Recurring bills template + help wiring)
- Fixed TemplateSyntaxError on recurring bills list by loading the `money` template filter library.
- Added a contextual Help button on Recurring Bills list pointing to Help Center → Accounting.

## 2026-02-16 — Phase 7H17 (Ops company UUID routes)
- Fixed Ops dashboard NoReverseMatch caused by UUID company IDs not matching `<int:company_id>` URL patterns.
- Ops company detail/timeline/resync URLs now use `<uuid:company_id>`.


## 2026-02-16 — Phase 7H18 (Template sanity + UUID company checks)
- Added `ez360_template_sanity_check` and wired it into Ops → Checks.
- Fixed Ops checks to treat Company IDs as UUID strings (no int casts).
- Updated smoke/idempotency commands to accept UUID company IDs.
- Added form validation: smoke test requires selecting a company.

## 2026-02-16 — Phase 7H19 (Ops checks indentation + template sanity hardening)
- Fixed an IndentationError in ops/views.py that prevented Django from loading config/urls.py.
- Hardened ez360_template_sanity_check to flag missing `{% load money %}` when templates use `|money` or `|money_cents`.

## 2026-02-16 — Phase 7H21 (URL sanity + Ops wiring)

- Added `ez360_url_sanity_check` command and wired it into Ops → Checks.
- Added Ops check kind `URL_SANITY`.
- Fixed OpsChecksForm indentation regression; added UUID-safe drift forms.

## 2026-02-16 — Phase 7H22 (Ops Run-All + Help Center expansion)
- Ops Checks: added **Run all** convenience option (runs everything; skips Smoke Test when no company selected).
- App shell: added **Help Center** link to the left sidebar.
- Help Center: expanded home page topic tiles to cover core workflows (Time, Invoices & Payments, Accounting, Billing, FAQ, Legal).

## 2026-02-16 — Phase 7H23 (Help Center fill + Template sanity expansion + Ops evidence export)
- Template sanity expanded: warns on POST forms missing `{% csrf_token %}` and warns on `{% url %}` tags using un-namespaced view names (heuristic).
- Help Center: added new pages for Recurring Bills, Refunds, and Ops Console; wired new tiles on Help Center home.
- Ops Checks: added one-click export of recent runs as a ZIP bundle (includes runs.csv + per-run output files).



## 2026-02-16 — Phase 7H24 (DONE)
- Expanded `ez360_url_sanity_check` to warn on obvious `{% url %}` positional arg-count mismatches for the top 20 most-used routes (best-effort).
- Added contextual help deep links:
  - Recurring Bills list → Help Center → Recurring Bills.
  - Payment/Refund screen → Help Center → Refunds.
  - Bill detail → Help Center → Accounting.
- Added scheduled/retention commands for Ops evidence:
  - `ez360_run_ops_checks_daily` (persist OpsCheckRun runs; intended for daily scheduler)
  - `ez360_prune_ops_check_runs` (retention by days, protects recent-per-kind)
- Help Center Ops Console updated with daily routine guidance.

## 2026-02-16 — Phase 7H26 (Help Center A/R + contextual help)

**Shipped:**
- Help Center: Accounts Receivable, Client Credits, A/R Aging pages added and linked from Help Home + Help sidebar.
- Reports: Accounts Aging report includes a contextual Help button.

**Why:**
- Corporate users expect “what does this page mean?” help directly from reports.
- A/R is core to finance workflows; documenting credits and aging reduces support load.

## 2026-02-16 — Phase 7H27 (Help Center A/R workflows + A/P Aging help + Production runbook)

**Shipped:**
- Help Center: added Collections, Statements, and Report interpretation pages (A/R workflows + report guidance).
- Help Center: added A/P Aging page; A/P Aging report now includes a contextual Help button.
- Help Center: added Production runbook page (deploy checks, daily ops checks, scheduling guidance, incident workflow).

**Why:**
- Finance-heavy apps need an in-product “how to run the business” layer—especially around collections and aging.
- A/P aging is a core control; help + a dedicated page prevents confusion and reduces support requests.

## 2026-02-16 — Phase 7H28
**DONE**
- Ops Checks: added Run recommended preset.
- Ops dashboard: added Copy Company ID button for UUID copy.
- Template sanity: warn when humanize filters are used without `{% load humanize %}`.

**NEXT**
- Continue template sweep: ensure `{% load money %}`/`{% load static %}`/`{% load humanize %}` where needed.
- Expand help content with screenshots placeholders and role-based permission tables.


## 2026-02-16 — Phase 7H30 (Statements + Help workflows + Ops alert routing)

**Shipped:**
- Documents: added **Client Statements** page (open invoices) with CSV export and optional PDF export (WeasyPrint if installed).
- Clients list: added quick action to open a client's Statement.
- Statements: added ability to email a statement notification to the client (templated email).
- Help Center: added role-based workflow guidance + screenshot placeholders for Time Tracking, Invoices & Payments, Accounting, and Statements.
- Ops: added DB-backed **Ops SiteConfig** singleton for alert routing (email/webhook), staff UI to edit it, and Ops Dashboard now shows recent alerts + link to routing.

**Notes:**
- Alert routing is best-effort and never breaks request paths.
- PDF export requires WeasyPrint (optional dependency).

## 2026-02-16 — Phase 7H31 (Statements polish + Ops deep links + Template sweep)

**Shipped:**
- Template sweep:
  - Fixed remaining un-namespaced `{% url 'home' %}` usages (404/500) to `core:home`.
  - Removed invalid parentheses in a `{% if %}` block (team list) to satisfy template sanity checks.
- Statements polish:
  - Added optional statement **date-range filter** (issue date; falls back to created date when issue date missing).
  - CSV/PDF exports honor the same date range.
  - Added `SITE_BASE_URL` setting so statement emails/PDFs can include a **“View statement”** link back into the app.
- Ops:
  - Added **alert detail** page and deep links from Ops dashboard “Recent alerts”.
  - Added **Send test alert** panel on Ops dashboard to exercise alert routing.
  - Added `ops_dashboard` as an alert source for auditability.
- Help Center:
  - Replaced placeholder text with actual placeholder images under `static/images/helpcenter/` (ready to swap with real screenshots).

**Notes:**
- `SITE_BASE_URL` should be set in production (ex: `https://ez360pm.com`). If blank, emails/PDFs simply omit the link.


## 2026-02-16 — Phase 7H33 (Statement email preview + PDF error hints + Ops JSON download + Help screenshots)

**Shipped:**
- Statements:
  - Added **Email preview** modal on Client Statement page (renders subject + HTML + text without sending).
  - Added a staff JSON endpoint to render the preview (`/documents/statements/client/<id>/email/preview/`).
  - Improved PDF export error messaging to differentiate “WeasyPrint missing” vs “render/deps failure” (Cairo/Pango hints).
- Ops:
  - Added **Details JSON download** (`/ops/alerts/<id>/details.json`).
  - Alert Detail shows a best-effort **Request ID** correlation value from alert details (copy button) when present.
- Help Center:
  - Replaced remaining screenshot text blocks with richer placeholder images for Statements, Time Tracking, and Invoices/Payments.

**NEXT:**
- Continue swapping screenshot placeholders for the Accounting pages.
- Inline warning UI on Statements page for missing `SITE_BASE_URL` and missing WeasyPrint.

## 2026-02-16 — Phase 7H34 (Help Center Accounting screenshots + Statement inline warnings + Ops alert quick-filters)

**Shipped:**
- Help Center: finished removing remaining "[Screenshot: ...]" text blocks and replaced Accounting screenshots with placeholder screenshot cards (CoA, Journal Entries, Reports index, General Ledger).
- Statements: added inline warning banner on the Statement page when `SITE_BASE_URL` is missing and/or WeasyPrint is not installed (so staff know why PDF / deep links may not work).
- Ops Alerts: KPI cards (Open/Webhooks/Email/Slow) now act as one-click quick-filters using querystring parameters.

**Why:**
- Help Center needs consistent, professional screenshot sections (even as placeholders) to serve as a launch manual.
- Statements should communicate environment limitations up-front (missing `SITE_BASE_URL` or WeasyPrint) to prevent “dead-end” actions.
- Ops quick-filters reduce time-to-triage while staying compatible with existing URL/querystring filtering.


## 2026-02-16 — Phase 7H35 (Ops alert pagination + Bulk resolve + Statement recipient defaults + Finance help permissions)

**Shipped:**
- Ops Alerts:
  - Added server-side **pagination** (50 per page) to keep the alerts screen fast.
  - Added a **bulk resolve** workflow (resolve selected on page, or resolve current filtered set up to 500).
- Statements:
  - Statement page now remembers the **last-used recipient email** per Client (scoped to Company) and uses it as the default next time.
  - Added **“Send test to myself”** action (sends the statement email to the logged-in user’s email).
- Help Center:
  - Added a standard **Permissions** table (Staff/Manager/Admin/Owner) to core finance/reporting articles.

**Notes:**
- Bulk resolve is capped (500) to prevent accidental mass changes.
- Statement recipient defaults are stored in `ClientStatementRecipientPreference`.


## 2026-02-16 — Phase 7H36
- Statements: added StatementReminder scheduling hook + send-due management command.
- Ops: added noise filters (path prefixes/user-agent tokens) and resolved-alert pruning command.


## 2026-02-16 — Phase 7H37
- Help Center: Production runbook now includes concrete scheduling guidance (Render cron examples) for daily ops checks, statement reminders, and pruning.
- Statements: reminder presets added (Friendly nudge / Past due) with dedicated email templates; reminders store tone and send the corresponding template.


## 2026-02-16 — Phase 7H38

**Shipped:**
- Ops Checks: added a **Render cron jobs** guidance card with copy/paste commands + link to Render docs.
- Statements: added a **cadence helper** (quick-pick dates like 3/7/14 days, next Monday, end-of-month) when scheduling reminders.
- Statements: added a **Last sent** table (recent sent reminders) for visibility and collections cadence.

**Notes:**
- Cadence suggestions are UI-only helpers; they don’t schedule anything until the user submits the form.


## 2026-02-16 — Phase 7H39

**Shipped:**
- Statements/Reminders:
  - Added `attempted_at` + `attempt_count` tracking to `StatementReminder` so failures have clear “last attempt” metadata.
  - `ez360_send_statement_reminders` now records an attempt timestamp/counter for every send attempt.
  - Statement page now shows a **Failed attempts** table (attempt time + last error) and supports **one-click reschedule (+7 days)**.
- Ops:
  - Ops Dashboard now includes copy/paste cron commands.
  - Added scheduler/env sanity warnings (SITE_BASE_URL + email backend/SMTP placeholder checks).

**Notes:**
- Attempt metadata is intentionally lightweight (timestamp + counter) and is updated even when the underlying send fails.
- Reschedule clears error state and sets the reminder back to SCHEDULED.


## 2026-02-16 — Phase 7H40

**Shipped:**
- Statements/Reminders:
  - Failed reminders UI now supports **reschedule-to-date** (date input) instead of only “+7 days”. Blank date still defaults to +7 days.
  - Added **Retry now** action (staff-only) to attempt sending a single reminder immediately, recording attempt metadata and updating status.
- Ops:
  - Expanded production scheduler/env sanity warnings to include **Stripe key presence**, **S3/storage readiness**, **backup S3 readiness**, and **SITE_BASE_URL domain alignment** against ALLOWED_HOSTS + CSRF_TRUSTED_ORIGINS.

**Notes:**
- “Retry now” is synchronous and intended for support workflows; scheduled sending still uses the management command.


## 2026-02-16 — Phase 7H41

**Shipped:**
- Statements/Email:
  - Added **“Email me a copy”** option when sending a client statement email.
  - Copy email is sent to the acting user’s email (best-effort) and logs `statement.emailed_copy`.
- Statements/Reminders (audit trail):
  - Added `StatementReminder.modified_by` to track who last changed a reminder.
  - Reminder create/cancel/reschedule/retry now sets `modified_by` + `updated_by_user` for clearer auditability.
  - Statement page now shows per-reminder **Scheduled by / Updated by + timestamp** for Scheduled / Failed / Sent tables.
- Ops Alerts:
  - Added **alert deduplication window** (SiteConfig: `ops_alert_dedup_minutes`) to coalesce identical open alerts.
  - Added **OpsAlertSnooze** (per-source, optional per-company) and a UI action to **Snooze alerts** from the alert detail page.

**Notes:**
- Dedup logic increments `details.dedup_count` and records `details.dedup_last_at` rather than creating new rows.
- Snooze suppresses *new* alerts for the source; it does not hide existing alert rows.


## 2026-02-16 — Phase 7H42

**Shipped:**
- Statements:
  - Statement email send supports **Tone** selection (Standard / Friendly nudge / Past due) and the Preview modal reflects the selected tone.
  - Reminder scheduler includes **Preview reminder email** action (tone + optional PDF attachment).
  - Added company-wide **Statement Reminders queue** with bulk cancel/reschedule.
- Ops:
  - Alerts list shows `dedup_count` and supports quick snooze from the list.
  - Added unresolved alerts CSV export (filters respected; capped).


## 2026-02-16 — Phase 7H43

**Shipped:**
- Statements:
  - Added staff/admin-only bulk action **Send now (selected)** for statement reminders (best-effort; capped).
  - Added **Reminder delivery report** (last 30 days: sent/failed by day) to the reminders queue.
- Ops:
  - Added **Open alerts summary** on Ops Dashboard grouped by **source** and **source+company** for faster triage.

**Notes:**
- Bulk send-now is intentionally capped for safety and records attempt metadata per reminder.


## 2026-02-16 — Phase 7H44 (DONE)
- Statements: added bulk **Send now (filtered set)** with confirmation + safety cap in Statement Reminders queue.
- Statements: added per-client statement activity tracking (last viewed/last emailed) and surfaced it on a new Client Detail page.
- Ops: added company_id filter to Ops Alerts list and updated Ops Dashboard deep links to preserve company scope.


## 2026-02-16 — Phase 8A (UI Foundation Hardening)

**Shipped:**
- UI foundation polish for launch prep:
  - Sidebar now highlights the active section automatically (JS marks the best matching sidebar link).
  - Active sidebar item includes a subtle left indicator bar (keeps layout stable).
  - Card style unified: `card shadow-sm` renders as borderless, rounded cards globally.
  - New typography helpers: `.ez-page-title` and `.ez-page-subtitle`.
  - Key list pages standardized on a consistent table style (`table-hover`, `align-middle`, `ez-table`).

**Applied to:** Dashboard, Clients, Documents list, Projects, Time tracking, Payments, Expenses.

**Phase 8B (started):**
- Dashboard now includes a **Quick actions** card (Track time + manager shortcuts for invoice/expense/client/project).


## 2026-02-16 — Phase 8B (Dashboard Redesign)

**Shipped:**
- Dashboard layout modernization:
  - KPI row (Revenue, Expenses, A/R, Unbilled hours) with “current month” label.
  - Recent Invoices + Recent Time panels.
  - Due-soon Projects panel.
  - Dashboard metrics are now context-complete (no missing template variables).


## 2026-02-16 — Phase 8C (Table Modernization)

**Shipped:**
- Standardized table/action UX across core modules:
  - Action columns now use **icon buttons + dropdown** (reduced clutter; consistent affordances).
  - Key list pages updated: Clients, Documents, Projects, Time entries, Payments, Expenses, Payables (Vendors/Bills).
- Added `doc_status_badge_class` template filter to standardize document status badge colors.

## 2026-02-16 — Phase 8D (DONE) — Forms UX Upgrade
- UI: Implemented sticky form action footer pattern (Cancel + Save) via `templates/partials/form_footer.html`.
- UI: Added `.ez-form` and `.ez-form-footer` styles to keep actions visible on long pages.
- Updated forms to use card-based sections and consistent actions:
  - Client form
  - Project form (split into Details / Schedule / Billing / Services)
  - Catalog item form
  - Document edit now uses sticky footer; moved credit/credit-note actions outside the main edit form.

## 2026-02-16 — Hotfix — Render DB missing TimeTrackingSettings columns

- Fixed production error on `/time/` where Postgres lacked `timetracking_timetrackingsettings.last_project_id`.
- Added migration `timetracking/migrations/0002_timetrackingsettings_timer_defaults.py` to add the missing fields:
  - `last_project` (FK → Project, nullable)
  - `last_service_catalog_item` (FK → CatalogItem, nullable)
- Deploy note: after pulling this change, run `python manage.py migrate` (no `makemigrations` needed).
- Follow-up hotfix: added migration `timetracking/migrations/0003_timetrackingsettings_timer_text_defaults.py` to add missing text fields referenced by code:
  - `last_service_name` (CharField)
  - `last_note` (TextField)



## 2026-02-16 — Phase 8E (DONE) — Empty States + First-run Guidance
- UI: standardized empty states with clear CTAs across Expenses and Payables lists.
- UI: improved Dashboard empty panels with actionable prompts (Create invoice; Start timer/Add time).
- UI: enhanced `includes/empty_state.html` to accept an `icon` parameter for consistent visuals.

## 2026-02-17 — Phase 8F (DONE) — Micro-interactions
- UI: auto-dismiss non-critical flash alerts (success/info) after a short delay.
- UX: global submit-guard on POST forms to prevent double submits and show inline spinner.
- UX: opt-in confirm helper via `data-ez-confirm` for destructive actions.

## 2026-02-17 — Phase 8G (DONE) — Help Center discoverability
- Added Help dropdown in the top-right app navbar (Help / Getting started / FAQ / Terms / Privacy).
- Public navbar Help link routes to the in-app Help Center.
- Added in-page Help sidebar search (client-side filter).

## 2026-02-17 — Phase 8H (DONE) — Brand pass
- Bootstrap CSS variable overrides to align core tokens (primary/success/link/border/body) with EZ360PM brand.
- Brand-aligned primary/outline button styling (subtle gradient) while remaining Bootstrap-compatible.
- Standardized form control radius + focus ring for a "financial-grade" feel (light + dark themes).

## 2026-02-17 — Phase 8I (DONE) — Mobile polish
- Prevented topbar/actions overflow on small screens.
- Made Timer dropdown responsive on phones.
- Ensured tables remain readable on mobile with predictable horizontal scrolling.
- Improved sticky form footer behavior on iOS via safe-area padding.

## 2026-02-17 — Phase 8J (DONE) — Launch Gate seeding
- Added default Launch Gate checklist definitions (`ops/launch_gate_defaults.py`).
- Added staff action to seed defaults from the Launch Gate page.
- Added management command: `python manage.py ez360_seed_launch_gate` (safe/no-overwrite).


## 2026-02-17 — Phase 8K (DONE) — Ops System Status page
- Added staff-only Ops → System status page to surface runtime info and **pending migrations** (helps catch deploy/migrate drift quickly).
- Linked System status from Ops dashboard.


## Phase 8L — Timer dropdown completion + Clients list company display (2026-02-17)
- Fixed navbar timer dropdown “missing company context” false-negative by hardening `core.context_processors._timer_context`:
  - Always renders the Project/Service/Notes form shell when company+employee context exists.
  - Surfaces a short `timer_unavailable_reason` instead of misleading messaging.
- Clients list now shows the client’s `company_name` (when present) under the client name for better B2B clarity.


## 2026-02-17 — Phase 8M (DONE)
- Fixed a syntax regression in `core/context_processors.py` that caused login to fail (IndentationError).
- Added **Ops → Smoke tests** page (`/ops/smoke/`) to quickly validate post-deploy/post-reset health.
- Added management command `python manage.py ez360_smokecheck` for CI/ops sanity checks (migrations + critical tables).
- Linked Smoke tests from Ops dashboard.


## 2026-02-17 — Phase 8N (DONE) — Comped access + discount tracking
- Added staff-only subscription overrides:
  - **Comped access** (free instance) with optional end date + reason
  - **Discount metadata** (% off + note + optional end date)
- Billing overview now displays **Comped** / **Discount** badges.
- Staff can manage overrides from the Billing page (staff-only panel).
- Admin lists now include comped/discount columns for quick auditing.


## 2026-02-17 — Phase 8O (DONE) — Go-live runbook export
- Added Ops → **Go-live runbook** page that aggregates Launch Gate readiness, pending migrations, and a manual verification checklist.
- Added export endpoints:
  - CSV: `/ops/runbook/export.csv`
  - PDF: `/ops/runbook/export.pdf`
- PDF generation uses **ReportLab** to avoid WeasyPrint system dependency issues during launch.
- Linked Go-live runbook from Ops dashboard for one-click access on launch day.


## Phase 8P — Maintenance Mode Toggle (Ops)
- Added maintenance mode fields to Ops SiteConfig (enabled/message/allow staff)
- Created MaintenanceModeMiddleware to show 503 maintenance page for non-staff when enabled
- Added maintenance.html template.


## Phase 8Q — List UX Counts (2026-02-17)
- Clients list: changed the header summary to show **range + total** (uses `page_obj.start_index/end_index` and `paginator.count`).
- Pagination footer (multi-page lists): now shows **page + range + total** for easier scanning and confidence.


## Phase 8R — Ops console + Runbook hotfix (2026-02-17)
- Fixed Ops Runbook template error by enabling Django's built-in **humanize** tag library (`django.contrib.humanize`).
- Fixed Ops Console toolbar overflow: wraps on desktop; uses horizontal scroll on smaller screens.
## 2026-02-17 — Phase 8S — Plan gating fixes (Expenses + Time Approval)
- **Expenses module** is now **Professional+** (`@tier_required(PlanCode.PROFESSIONAL)`) across merchants + expenses + receipt open.
- **Time approval workflow** is now **Professional+**:
  - `time_entry_approve` is gated to Professional+.
  - Starter users cannot enable manager-approval: the `require_manager_approval` setting is hidden and forced off on save.
  - If a Starter user has manager-approval enabled from older data, submit now auto-approves (no dead-end).

## 2026-02-17 — Phase 8T — Navigation gating polish
- Sidebar navigation now hides plan-restricted modules so users do not see features their subscription does not include:
  - **Expenses** hidden unless **Professional+**.
  - **Accounting** hidden unless **Professional+**.
  - **Integrations (Dropbox)** hidden unless **Premium**.

## 2026-02-17 — Phase 8U — Tiered dashboard widgets (Starter/Pro/Premium)

- Dashboard now respects subscription tiers:
  - Starter no longer shows **Expenses** KPI or **Payables** card.
  - Professional+ shows **Expenses** KPI and **Payables** summary.
- Added **Premium insights** card (Premium + Manager+) with:
  - Revenue trend vs last month
  - Expense trend vs last month (when Professional+ data exists)
  - Overdue invoices count + overdue balance
  - Dropbox connection status + link to settings
- Fixed Subscription card on dashboard to use `SubscriptionSummary` fields (plan/status/trial/seats).
- Server-side gating remains authoritative; this is UI alignment only.

## 2026-02-17 — Phase 8V — Premium Custom Dashboards (v1)

- Implemented Premium-only dashboard customization (per-company, per-role).
- Added `core.DashboardLayout` model + migration to store widget layout JSON (`left` / `right` columns).
- Added **Customize Dashboard** page (`core:dashboard_customize`) for Premium Manager+:
  - Enable/disable widgets
  - Choose column (left/right)
  - Set display order
- Refactored dashboard rendering to be widget/include-based and driven by resolved layout.
- Guardrails: runtime sanitization drops unknown/disallowed widgets and enforces required basics.

## 2026-02-17 — Phase 8S — Bank Feeds Scaffold (Integrations)

- Added **Bank feeds** integration scaffold (Professional+).
- New models in `integrations`: `BankConnection`, `BankAccount`, `BankTransaction`.
- Added admin registration + basic UI page: `/integrations/banking/`.
- Added env toggles: `PLAID_ENABLED`, `PLAID_CLIENT_ID`, `PLAID_SECRET`, `PLAID_ENV`.
- This is intentionally **scaffold-only** (no Plaid SDK dependency yet). Next pack will implement secure Link + transaction sync.

- 2026-02-17: Phase 8T — Implemented Plaid Bank Feeds integration (Link token, public token exchange, accounts import, transactions sync, create expense from transaction), added sync_cursor migration and updated banking settings UI.



## Hotfix – Invoice page RecursionError (template include in comment)
- Fixed `templates/partials/form_footer.html` docstring to remove a literal `{% include %}` example that could trigger recursive rendering in some environments.
- No DB changes.

## Hotfix – Dropdown styling sweep (select widgets)
- Improved `.form-select` styling for a more polished, intentional look across the app.
- Added a client-side safety sweep to apply `form-select` to any `<select>` elements missing Bootstrap classes.

## Phase 8W — Plaid readiness hardening (ship-safe)
- Plaid Link JS now only loads when Bank Feeds are **enabled + configured** (prevents unnecessary external script load).
- Bank Feeds page now clarifies **sandbox vs production** and Plaid business verification expectations.

## 2026-02-17 — Phase 8U — Bank feed rules + transaction triage

- Added `integrations.BankRule` model (per-company) with priority ordering and actions:
  - Suggest category
  - Ignore
  - Mark as transfer
  - Auto-create draft expense (optional)
- Enhanced `integrations.BankTransaction` with status + suggestion fields + linked expense + applied rule.
- Rules apply automatically after bank sync and can also be applied manually.
- Banking page now shows status + suggestions and includes quick actions (Create expense / Ignore / Transfer).
- Added rule management UI (list/create/edit/delete) gated to Professional tier + Admin+.
- Admin registrations added for `BankRule` and improved `BankTransaction` admin.

## 2026-02-18 — Phase 8X — Bank review queue + duplicate prevention

- Added a dedicated **Bank Review Queue** page: `/integrations/banking/review/` (Professional+).
  - Filter by status and account
  - Pagination for large imports
- Added **bulk processing** actions:
  - Ignore selected
  - Mark transfers
  - Create draft expenses (skips ineligible + skips strong duplicate candidates)
  - Link to suggested existing expense (when a candidate match is found)
- Implemented **conservative duplicate suggestion** heuristic:
  - Matches existing expenses by amount + date window (+/- 1 day) + merchant name match
  - Stored per transaction as `suggested_existing_expense` + `score` (non-binding)
- Added **Reconcile** summary view: `/integrations/banking/reconcile/` with windowed counts and per-account breakdown.

## 2026-02-18 — Phase 8S2 — V1 Launch Manual + End-to-End QA Punchlist

- Published a **User Manual PDF** at `static/docs/ez360pm_user_manual.pdf` and linked it from the Help Center home page.
- Added a staff-only **Ops → QA Punchlist** module:
  - CRUD for QA issues (status, severity, area, company, repro steps, expected vs actual, resolution notes)
  - Filters, search, pagination, and open/in-progress counts
- Ops Dashboard now shows a badge count for open/in-progress QA issues.

## 2026-02-18 — Phase 8Y — V1 Launch Polish + QA Fix Sprint

- Added a staff-only **Report issue** shortcut (bug icon) in the app topbar.
  - Opens Ops → QA “New issue” with the current page URL prefilled.
  - Auto-guesses the issue area from the URL prefix and preserves active company context.
- QA “New issue” view supports safe querystring prefill (`related_url`, `area`, `company`).

## 2026-02-18 — Phase 9 — Bank reconciliation periods (lockable)

- Added `integrations.BankReconciliationPeriod`:
  - Per-company reconciliation windows (`start_date`, `end_date`).
  - Status: `open` or `locked` with `locked_at` / `locked_by`.
  - Snapshot fields saved on lock (bank outflow, expense totals, matched/unmatched counts).
- Added reconciliation UI (Professional+):
  - Periods list + create period.
  - Period detail with diffs + unmatched bank tx / unmatched expenses.
  - Lock / Undo lock actions (Admin+).
  - CSV export of all transactions in the period.


## 2026-02-17 — Phase 9 QA Plan Added
- Added `docs/QA_PLAN.md` to drive a feature-by-feature validation loop for v1 readiness.
- Plan includes: QA loop, execution order, environment/seed expectations, QA Ledger template, and Fix Pack conventions (`P9-*`).
- `docs/FEATURE_INVENTORY.md` now links to the Phase 9 QA plan as the execution driver.

## 2026-02-18 — Phase 9 — UI Consistency Sweep + Boot Fixes (P9-UI1)

- Fixed app boot error in Integrations module:
  - Restored backwards-compatible `companies.services.get_active_employee()` alias (maps to `get_active_employee_profile`).
- Hardened Ops QA indexes for cross-DB compatibility:
  - Shortened `ops.QAIssue` index names to <= 30 chars.
  - Updated migration `0003_qaiissue` and added `0004_rename_qa_indexes` for safe rename on existing DBs.
- UI consistency:
  - Standardized remaining straggler pages to use `card shadow-sm` so cards match across the app.

## 2026-02-17 — Phase 9 — UI Consistency Sweep + Timer Bug Fix (P9-UI2)

- UI consistency:
  - Standardized remaining list/detail pages to use `card shadow-sm` so the Phase 8 card system applies everywhere.
  - Removed stray `bg-white` card headers on Time Tracking pages so headers inherit the standardized card header styling.
- Bug fix (Timer):
  - Fixed invalid nested `<form>` markup on the Timer page (Start Timer flow).
    - “Clear” is now a separate sibling form (still inline) to prevent broken submits in some browsers.

## 2026-02-17 — Phase 9 — "Paper" Document Composer (P9-DOC-COMPOSER)

- Implemented a document editor layout that looks like an editable version of the final PDF (centered “paper” surface).
- Added page-specific assets for the composer:
  - `static/css/document_composer.css`
  - `static/js/document_composer.js`
- Live in-browser totals:
  - Per-line totals
  - Subtotal / tax / total
  - Invoice deposit guidance (percent or fixed) + “balance after deposit”
- Line items support:
  - Add-line button (formset `TOTAL_FORMS` increments correctly)
  - Catalog auto-fill (name/description/rate/taxable) via `catalog:item_json`
- Template system:
  - Added `{% block extra_css %}` / `{% block extra_js %}` to `base_app.html` to support feature page assets.
- Composer uses existing persisted fields:
  - `sales_tax_percent`
  - `deposit_type` (none|percent|fixed) + `deposit_value` + computed `deposit_cents`
  - `terms` (invoice)


## 2026-02-18 — Phase 9 (P9-DOC-LOGO-SAFE)
- Fixed 500 on document edit/print when resolving `company.logo.url` under misconfigured S3/boto endpoint.
- Added `safe_media_url` template filter (`core.templatetags.media_extras`) and updated document composer + PDF/print templates to use it with a static logo fallback.

## 2026-02-18 — Phase 9 (P9-DOC-PDF-PARITY)
- Print/preview polish for customer-facing output:
  - Added a real **Print** button on the HTML preview toolbar.
  - Ensured logo rendering uses `|safe_media_url` *and* falls back to the static EZ360PM logo when the media backend is misconfigured.
- Goal: keep the print/PDF output resilient and visually aligned with the composer.

## 2026-02-18 — Phase 9 (P9-DOC-TEMPLATE-BLOCKS)
- Added `Document.header_text` and `Document.footer_text` fields.
- Wizard: creating from a `DocumentTemplate` now copies `header_text` / `footer_text` into the document.
- Composer: added editable Header/Footer blocks to the paper editor.
- Print/PDF output: renders header near the top and footer near the bottom.

## 2026-02-18 — Phase 9 (P9-QA0-ISOLATION-TESTS)
- Added automated regression tests to protect the company isolation invariant:
  - Active company auto-selection when missing from session on company-scoped pages.
  - Cross-company document access returns 404 for edit/print routes.

## P9-LEGAL-PAGES (2026-02-18)
- Fixed footer legal links (Terms/Privacy/Cookies/Security/Acceptable Use/Refund Policy) by adding missing templates under helpcenter.
- Added smoke tests to ensure legal pages render (HTTP 200).


## Phase 9 – P9-SCANNER-SHIELD
- Added ScannerShieldMiddleware to short-circuit common bot/scanner endpoints (e.g. /webhook-test, /.env) and reduce log noise.
- Added core tests for blocked probe paths.
- Added helpcenter to INSTALLED_APPS to ensure legal/help pages render in production.

## 2026-02-18 — Phase 9 (P9-NAV-SMOKE)
- Added navigation smoke tests (`core/tests/test_nav_smoke.py`) covering:
  - Public landing + footer legal links
  - Public legal pages (Terms/Privacy/Cookies/Security)
  - Key authenticated entry points (dashboard, clients, projects, invoices, expenses, help center)
- Purpose: catch TemplateDoesNotExist/NoReverseMatch and other dead-end navigation regressions before deploy.


## 2026-02-18 — P9-TESTING-GUIDE

- Added `docs/TESTING.md` as the canonical testing guide (local + pre-deploy workflow, common failures, and Phase 9 must-pass targets).

## 2026-02-18 — Phase 9 (P9-OPS-HEALTH-ENDPOINTS)

- Added safe health endpoints for monitoring:
  - `GET /health/` (public, minimal, returns 200/503)
  - `GET /health/details/` (token-protected; disabled unless `HEALTHCHECK_TOKEN` is set)
- Added docs:
  - `docs/PRODUCTION_BASELINE.md`
  - `docs/LAUNCH_GATE_CHECKLIST.md`
- Updated `docs/ENV_VARS.md` with `HEALTHCHECK_TOKEN`.

## 2026-02-18 — Phase 9 QA1 Manual Checklist + Seed
- Added `docs/MANUAL_QA_CHECKLIST.md` as the launch-gate, click-by-click verification list (staging then production).
- Added `python manage.py seed_qa` management command to quickly seed demo company/client/project/service/invoice/expense data for local/manual testing.
- Added missing `__init__.py` for `core.management` packages (stability across environments).

## 2026-02-18 — Phase 9 (P9-FOOTER-IN-APP)
- Added the same legal footer links to **logged-in** pages by introducing a shared footer partial and including it in both `base_public.html` and `base_app.html`.

## 2026-02-19 — Phase 9 (P9-DASHBOARD-PREMIUM)
- Premium dashboard layout upgrade (kept existing KPI cards + activity widgets).
- Added Chart.js-based widgets:
  - Revenue trend (last 6 months, payments received)
  - A/R aging buckets (Current, 1–30, 31–60, 61–90, 90+)
- Added lightweight JSON endpoints under `/app/dashboard/api/` for charts.
- Updated dashboard controls to use branded button styling.

## 2026-02-19 — Phase 9 (P9-DASHBOARD-NOTES-LAYOUT)

- Dashboard header now shows **User name + role** above the Dashboard title (removed the generic tagline).
- Right rail simplified to reduce clutter:
  - Kept Quick actions.
  - Getting started widget now auto-hides once onboarding is 100%.
  - Added **Quick notes** widget for call/intake capture.
- Added a new **Notes** module:
  - `notes.UserNote` (company-scoped, user-owned)
  - `/notes/` page to create/search/view notes
  - Sidebar “Notes” nav item
- Removed dashboard “Active company / Role / Subscription” widgets from the default layout (active company is shown under the company dropdown in the sidebar; subscription lives under Billing).
